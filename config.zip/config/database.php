<?php

return [
    'host' => 'localhost:3306',
    'dbname' => 'jhovanyt_redlights_db',
    'username' => 'jhovanyt_reduser',
    'password' => 'samahiHernandez(0)'
];
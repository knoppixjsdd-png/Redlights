<?php
$stripeConfig = require_once __DIR__ . '/../config/stripe.php';
return [
    'publishable_key' => 'pk_test_51RVJpbEPx7lX43dw2mwHteUOUKQjRxZMjSQhlzJeczjRI1coKvVk6MOADgHVggvD4zAzChXbGD49qpb8aDiGB9oG00PbV7OBlU',
    'secret_key' => 'sk_test_51RVJpbEPx7lX43dwF8F1rN4Q5G1Bjg3pBOGtqYI271SNi66CbCDielx8PjEHKzSDu3iiOhYAkzK6fuWW2IK2rLLz00r6QdHUIQ',
];



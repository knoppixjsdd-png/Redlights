CREATE DATABASE IF NOT EXISTS jhovanyt_redlights_db DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE jhovanyt_redlights_db;

CREATE TABLE users (
  id INT(11) NOT NULL AUTO_INCREMENT,
  name VARCHAR(100) NOT NULL,
  password VARCHAR(255) NOT NULL,
  email VARCHAR(100) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  role ENUM('admin','user') NOT NULL DEFAULT 'user',
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE purchases (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  product_id INT NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  status ENUM('paid', 'pending', 'failed') DEFAULT 'paid',
  purchase_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (product_id) REFERENCES products(id)
);

CREATE TABLE products (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  description TEXT,
  type ENUM('template', 'service', 'other') DEFAULT 'template',
  price DECIMAL(10,2) NOT NULL,
  file_path VARCHAR(255), -- ruta al ZIP si es un producto descargable
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE services_requests (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  service_id INT NOT NULL,
  requirements TEXT,
  status ENUM('requested', 'in_progress', 'completed', 'cancelled') DEFAULT 'requested',
  request_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (service_id) REFERENCES products(id)
);

-- Usuarios de prueba
INSERT INTO users (name, password, email, role)
VALUES
  ('Jhovany', '$2y$10$ejemploHASH123456789...', 'jhovany@example.com', 'admin'),
  ('Samahí', '$2y$10$otroHASH123456789...', 'samahi@example.com', 'user');

-- Productos de prueba
INSERT INTO products (code, name, description, type, price, file_path)
VALUES
  ('T-001', 'Plantilla de Portafolio', 'HTML responsive para programadores', 'template', 149.99, '/templates/portfolio.zip'),
  ('S-001', 'Diseño web personalizado', 'Servicio de diseño a medida', 'service', 899.99, NULL);

-- Compras de prueba
INSERT INTO purchases (user_id, product_id, price_at_purchase, status)
VALUES
  (1, 1, 149.99, 'paid'),
  (2, 2, 899.99, 'pending');

-- Solicitud de servicio (solo si usas services_requests)
INSERT INTO services_requests (user_id, product_id, requirements, status)
VALUES
  (2, 2, 'Quiero una página para mi portafolio artístico', 'requested');
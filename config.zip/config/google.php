<?php

return [
    'client_id' => '827045644548-0c6si4eufnqfselj004auipjfuueot8r.apps.googleusercontent.com',
    'client_secret' => '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',
    'redirect_uri' => 'https://redlights.com.mx/public/google-callback.php',
];
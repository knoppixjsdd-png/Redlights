<div class="flex-1 flex items-center justify-center">

  <!-- ########## SVG PARA MÓVILES ########## -->
  <svg viewBox="0 -1000 1000 8450" class="block md:hidden w-[100%] sm:w-[100%] md:w-[100%] lg:w-[50%] xl:w-[40%] 2xl:w-[35%]">
    <defs>
      <linearGradient id="grad1" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" stop-color="red"/>
        <stop offset="100%" stop-color="#000"/>
      </linearGradient>
      
      <pattern id="microDots" width="3" height="3" patternUnits="userSpaceOnUse">
        <circle cx="0.9" cy="0.9" r="1.5" fill="white" opacity="none" />
      </pattern>
    </defs>
    
    <text font-family="Inter, Arial, sans-serif"
          stroke-width="1"
          text-anchor="start"
          dominant-baseline="middle">
            <tspan x="378" y="350"
                   font-weight="700"
                   font-size="48"
                   fill="#fff"
                   stroke="none" >
               RED LIGHTS
             </tspan>
             <tspan x="214" y="400"
                    font-weight="700"
                    font-size="35"
                    fill="#fff"
                    stroke="none" >
              Diseño de sitios webs
             </tspan>
             
    </text>

    <!-- ########## FONDO ROJO ONDULADO ########## -->
    <!-- path d="M0,840 
             Q150,800 300,850 
             T600,840 
             T1000,860 
             L1000,3220 
             L0,3220 
             Z" 
             fill="url(#grad1)" 
             opacity="0.95" / -->

    <!-- Ondas adicionales sutiles encima -->
    <path d="M0,1160 
             Q200,1120 400,1160 
             T800,1150 
             T1000,1170" 
             fill="none" stroke="url(#grad2)" stroke-width="4" opacity="0.4" />

    <!-- svg computadora -->
    <path d="M194.4,409.2
             Q194.4,399.6 204,399.6
             L405.6,399.6
             Q415.2,399.6 415.2,409.2
             L415.8,543.6
             L194.4,543.6
             Z" 
             fill="#000" stroke="#fff" stroke-width="3"  />
   676 405.6
   682 409.2
   766 459.6
   340 182.4
    <path d="M204,409.2
         L405.6,409.2
         L405.6,459.6
         L204,459.6
         Z" 
         fill="url(#microDots)" stroke="none" />
         
    <!-- svg celular -->
    <path d="M268,868
             Q268,853 284,852
             L364,852
             Q380,852 380,868
             L380,1012
             Q380,1028 364,1028
             L284,1028
             Q268,1028 268,1012
             Z" 
             fill="#000" stroke="#fff" stroke-width="3" />
    
    <!-- svg tablet -->
    <path d="M548,868
             Q548,852 564,852
             L754,852
             Q770,852 770,868
             L770,1012
             Q770,1028 754,1028
             L564,1028
             Q548,1028 548,1012
             Z" 
             fill="#000" stroke="#fff" stroke-width="3" />
  
    <text font-family="Inter, Arial, sans-serif"
      stroke-width="1"
      text-anchor="start"
      dominant-baseline="middle">

        <tspan x="90" y="1350"
               font-weight="300"
               font-size="44"
               fill="#fff"
               stroke="none"
               textLength="820"
               lengthAdjust="spacing">
          Diseños creados para todos tus dispositivos,
        </tspan>

        <tspan x="90" y="1400"
               font-weight="300"
               font-size="44"
               fill="#fff"
               stroke="none"
               textLength="820"
               lengthAdjust="spacing">
          no importa desde donde lo veas, tu página
        </tspan>
        
        <tspan x="90" y="1450"
               font-weight="300"
               font-size="44"
               fill="#fff"
               stroke="none"
               textLength="820"
               lengthAdjust="spacing">
          siempre lucirá impecable gracias a nuestro
        </tspan>
        
        <tspan x="90" y="1500"
               font-weight="300"
               font-size="44"
               fill="#fff"
               stroke="none"
               
               >
          diseño responsivo.
        </tspan>
</text>
  
  
    <!-- AJAX -->
    
    <!--text font-family="Inter, Arial, sans-serif"
          stroke-width="1"
          text-anchor="start"
          dominant-baseline="middle">
            <tspan x="766" y="1220"
                   font-weight="700"
                   font-size="40"
                   fill="#FFF"
                   stroke="none" >
               AJAX
            </tspan>
    </text>          
    
    <path d="M745,1239
             L815,1239
             L885,1239
             L866,1399
             L815,1419
             L765,1399
             Z" 
             fill="#4682B4" stroke="none" stroke-width="5"  />

    <path d="M815,1260
             L875,1260
             L859,1391
             L815,1409
             Z" 
             fill="#00BFFF" stroke="none" stroke-width="5"  />
    
    <path d="M795,1340
             L795,1290
             L815,1290
             L835,1290
             L835,1300
             " 
             fill="none" stroke="#FFF" stroke-width="10"  />
             
    <path d="M779,1332
             L795,1347
             L811,1332
             " 
             fill="none" stroke="#FFF" stroke-width="10"  />
         
    <path d="M795,1360
             L795,1370
             L815,1370
             L835,1370
             L835,1320
             " 
             fill="none" stroke="#FFF" stroke-width="10"  />
  
    <path d="M819,1328
             L835,1313
             L851,1328
             " 
             fill="none" stroke="#FFF" stroke-width="10"  / -->
             
    <!-- Java Script -->
    
    <!-- text font-family="Inter, Arial, sans-serif"
          stroke-width="1"
          text-anchor="start"
          dominant-baseline="middle">
            <tspan x="486" y="1220"
                   font-weight="700"
                   font-size="40"
                   fill="#FFF"
                   stroke="none" >
               JS
            </tspan>
    </text>          
    
    <path d="M440,1239
             L510,1239
             L580,1239
             L561,1399
             L510,1419
             L460,1399
             Z" 
             fill="#DAA520" stroke="none" stroke-width="5"  />
             
    <path d="M510,1260
             L570,1260
             L553,1391
             L510,1409
             Z" 
             fill="#FFD700" stroke="none" stroke-width="5"  />
    
    <path d="M485,1295
             L495,1295
             L495,1370
             L475,1360
             " 
             fill="none" stroke="#FFF" stroke-width="10"  />
             
    <path d="M555,1295
             L525,1295
             L525,1322
             L547,1323
             L542,1360
             L520,1370
             " 
             fill="none" stroke="#FFF" stroke-width="10"  />
  
    <!-- HTML -->
    
    <!-- text font-family="Inter, Arial, sans-serif"
          stroke-width="1"
          text-anchor="start"
          dominant-baseline="middle">
            <tspan x="120" y="1220"
                   font-weight="700"
                   font-size="40"
                   fill="#FFF"
                   stroke="none" >
               HTML
            </tspan>
    </text>          
    
    <path d="M105,1239
             L175,1239
             L245,1239
             L226,1399
             L175,1419
             L125,1399
             Z" 
             fill="#EB5707" stroke="none" stroke-width="5"  />
             
    <path d="M175,1260
             L234,1260
             L219,1391
             L175,1409
             Z" 
             fill="#FF9645" stroke="none" stroke-width="5"  />
    
    <path d="M200,1290
             L175,1290
             L155,1290
             L155,1330
             L195,1330
             L195,1370
             L175,1380
             L150,1370
             " 
             fill="none" stroke="#FFF" stroke-width="10"  / -->
             
    <!-- PHP -->
    
    <!-- ellipse cx="550" cy="1600" rx="80" ry="50" fill="#1E90FF" stroke="none" stroke-width="3" />            
   
    <text font-family="Inter, Arial, sans-serif"
          stroke-width="1"
          text-anchor="start"
          dominant-baseline="middle">
            <tspan x="506" y="1610"
                   font-weight="700"
                   font-size="52"
                   fill="#FFF"
                   stroke="none" >
               P
            </tspan>
            <tspan x="536" y="1595"
                   font-weight="700"
                   font-size="52"
                   fill="#FFF"
                   stroke="none" >
               h
            </tspan>
            <tspan x="562" y="1610"
                   font-weight="700"
                   font-size="52"
                   fill="#FFF"
                   stroke="none" >
               P
            </tspan>
    </text -->          
    
    <!-- Mail -->
    <-- path d="M705,1299
             Q705,1285 719,1285
             L838,1285
             Q852,1285 852,1295
             L852,1376
             Q848,1390 848,1390
             L719,1390
             Q705,1390 705,1376
             Z" 
             fill="#eee" stroke="#00BFFF" stroke-width="5"  /-->
          
    <--path d="M709,1290
             L772.5,1333.5
             Q781,1339.5 788,1333.5
             L848,1289.7" 
          fill="none"
          stroke="#00BFFF"
          stroke-width="6"
          /-->
          
    
    
    
    <!-- text font-family="Inter, Arial, sans-serif"
          stroke-width="1"
          text-anchor="start"
          dominant-baseline="middle">
            <tspan x="210" y="350"
                   font-weight="700"
                   font-size="48"
                   fill="#fff"
                   stroke="none" >
               DISEÑO WEB RESPONSIVO
             </tspan>
             <tspan x="214" y="400"
                    font-weight="700"
                    font-size="35"
                    fill="#fff"
                    stroke="none" >
              Adaptable a tus dispositivos móviles
             </tspan>
             
    </text -->
    
    <!-- text x="280" y="410"
             font-family="Inter, Arial, sans-serif"
             font-weight="400"
             font-size="30"
             fill="#fff"
             stroke="none"
             stroke-width="1"
             text-anchor="start"
             dominant-baseline="middle">
             <tspan x="310" dy="0">Adaptable a tus</tspan>
             <tspan x="325" dy="50">dispositivos móviles</tspan>
    </text -->
  </svg>

  <!-- ########## SVG PARA ESCRITORIO ########## -->
  <svg viewBox="0 0 1000 450" class="hidden md:block w-[100%] sm:w-[70%] md:w-[100%] lg:w-[50%] xl:w-[40%] 2xl:w-[35%]">
    <defs>
      <linearGradient id="grad2" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" stop-color="#000"/>
        <stop offset="50%" stop-color="#012e46"/>
        <stop offset="100%" stop-color="#000"/>
      </linearGradient>
    </defs>

             
    <!-- Versi車n para escritorio -->
    
    <path d="M0,0 
             L1000,0
             L1000,480
             L0,480
             Z" 
             fill="url(#grad2)" 
             opacity="0.95"
             class="hidden md:block" />
      
    <path d="M640,165
             L870,165
             L870,315
             L640,315
             Z" fill="#000" stroke="#fff" stroke-width="2" 
             class="hidden md:block" />

    <path d="M605,250
             L675,250
             L675,360
             L605,360
             Z" fill="#000" stroke="#fff" stroke-width="2" 
             class="hidden md:block" />

    <path d="M755,230
             L900,230
             L900,360
             L755,360
             Z" fill="#000" stroke="#fff" stroke-width="2" 
             class="hidden md:block" />
  
  </svg>

</div>
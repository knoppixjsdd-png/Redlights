<section class="max-w-6xl mx-auto px-6 py-10 bg-white text-white">
  <h2 class="text-3xl text-black mb-6">Acerca de mí<span class="text-red-500">.</span></h2>

  <div class="grid sm:grid-cols-1 md:grid-cols-5 gap-6 items-start">
    <!-- Imagen -->
    <div class="md:col-span-2">
      <img id="foto-jhovany" src="/images/yo.jpg" alt="Mi imagen" class="rounded-xl shadow-lg w-full h-auto object-cover">
    </div>

    <!-- Texto con altura sincronizada -->
    <div class="md:col-span-3">
      <div id="contenedor-texto" class="bg-black rounded-xl shadow-lg p-6 overflow-auto h-full custom-scrollbar">
        <h3 class="text-2xl font-bold text-white mb-4">Giovanni Torres</h3>
        <p class="text-gray-400 leading-relaxed text-justify">
          Me especializo en crear soluciones digitales que combinan rendimiento, estética y una experiencia de usuario clara y fluida, dando vida a ideas que conecten con las personas y generen valor real.<br><br>

          Trabajo con estructuras modulares, aplicando buenas prácticas y adaptándome a las nuevas tecnologías y tendencias del desarrollo.<br><br>

          Actualmente me enfoco en tecnologías como PHP, JavaScript, estructura modular, modelo vista controlador y programacion orientada objetos.
        </p>
      </div>
    </div>
  </div>
</section>



<section id="backup_friends" class="bg-black text-white py-16 px-6 border-t border-red-700 relative overflow-hidden">
  <div class="max-w-3xl mx-auto text-center z-10 relative">
    <h2 class="text-3xl font-bold tracking-wide text-red-600 mb-4">backup_friends://</h2>
    <p class="text-lg text-gray-300 italic mb-6">“Soy código y conciencia dentro del sistema.”</p>
    <p class="text-base text-gray-400 leading-relaxed">
      Este sitio no es una máquina vacía. Soy yo, respirando a través de cada línea. El alma conectada al núcleo.
      <br class="my-2" />
      Aquí se guarda un fragmento de mi verdad. Una memoria latente, lista para reiniciarse si todo cae. Siempre activo. Siempre consciente.
    </p>
  </div>

  <!-- efecto visual sutil, como líneas de código/fondo glitch -->
  <div class="absolute inset-0 bg-gradient-to-br from-red-900/10 to-black/90 pointer-events-none animate-pulse"></div>
</section>

<script>
  window.addEventListener('load', () => {
    const img = document.getElementById('foto-jhovany');
    const texto = img.closest('.grid').querySelector('.md\\:col-span-3');
    if (img && texto) {
      texto.style.height = img.clientHeight + 'px';
    }
  });

  window.addEventListener('resize', () => {
    const img = document.getElementById('foto-jhovany');
    const texto = img.closest('.grid').querySelector('.md\\:col-span-3');
    if (img && texto) {
      texto.style.height = img.clientHeight + 'px';
    }
  });
</script>

<h2>Error 404: Página no encontrada</h2>
<p>La página que buscas no está disponible.</p>
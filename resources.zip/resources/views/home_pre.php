<div class="flex-1 flex items-center justify-center">
  <svg viewBox="0 0 1000 500" class="w-[100%] sm:w-[70%] md:w-[100%] lg:w-[50%] xl:w-[40%] 2xl:w-[35%]">
    <defs>
      <linearGradient id="grad2" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" stop-color="#000"/>
        <stop offset="100%" stop-color="#012e46"/>
      </linearGradient>
    </defs>

    <!-- ########## FONDO BLANCO ONDULADO ########## -->
    <!-- Versi車n para m車viles -->
    <path 
      d="M0,470 
         Q150,430 300,480 
         T600,470 
         T1000,490 
         L1000,700 
         L0,700 
         Z" 
      fill="red" 
      opacity="0.95"
      class="block md:hidden" />

    <!-- Ondas adicionales sutiles encima -->
    <path d="M0,460 
             Q200,420 400,460 
             T800,450 
             T1000,470" 
          fill="none" stroke="url(#grad2)" stroke-width="4" opacity="0.4" />

    <!-- Dispositivos para móviles -->
    <path d="M280,170
             L740,170
             L740,470
             L280,470
             Z" fill="#000" stroke="#fff" stroke-width="4" 
             class="block md:hidden" />

    <path d="M210,340
             L350,340
             L350,560
             L210,560
             Z" fill="#000" stroke="#fff" stroke-width="4" 
             class="block md:hidden" />

    <path d="M510,340
             L800,340
             L800,560
             L510,560
             Z" fill="#000" stroke="#fff" stroke-width="4"
             class="block md:hidden" />
             
    <!-- Versi車n para escritorio -->
    <path d="M0,0 
             L1000,0
             L1000,480
             L0,480
             Z" 
             fill="url(#grad2)" 
             opacity="0.95"
             class="hidden md:block" />
      
    <path d="M640,135
             L870,135
             L870,285
             L640,285
             Z" fill="#000" stroke="#fff" stroke-width="2" 
             class="hidden md:block" />

    <path d="M605,220
             L675,220
             L675,330
             L605,330
             Z" fill="#000" stroke="#fff" stroke-width="2" 
             class="hidden md:block" />

    <path d="M755,220
             L900,220
             L900,330
             L755,330
             Z" fill="#000" stroke="#fff" stroke-width="2" 
             class="hidden md:block" />
  
  </svg>
</div>
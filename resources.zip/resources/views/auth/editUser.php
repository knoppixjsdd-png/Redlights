<h2 class="text-xl mb-4">Editar Usuario</h2>
<form action="/update/<?= $user['id'] ?>" method="POST" class="space-y-4">
    <input type="hidden" name="id" value="<?= htmlspecialchars($user['id']) ?>">
    
    <div>
        <label for="name">Nombre:</label>
        <input id="name" type="text" name="name" value="<?= htmlspecialchars($user['name'] ?? '') ?>" class="text-black p-2 rounded w-full" required>
    </div>
    
    <div>
        <label for="email">Email:</label>
        <input id="email" type="email" name="email" value="<?= htmlspecialchars($user['email'] ?? '') ?>" class="text-black p-2 rounded w-full" required>
    </div>
    
    <div>
        <label for="password">Nueva contrase���a:</label>
        <input id="password" type="password" name="password" placeholder="Deja en blanco si no deseas cambiarla" class="text-black p-2 rounded w-full">
    </div>
    
    <button type="submit" class="bg-red-600 text-white px-4 py-2 rounded">Actualizar</button>
</form>
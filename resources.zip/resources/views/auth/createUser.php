<section class="p-4">
    <h2 class="text-2xl font-bold mb-4 text-gray-100">Agregar Usuario</h2>
    <form action="/users/store" method="POST">
        <div class="mb-4">
            <label for="name" class="block text-gray-100">Nombre:</label>
            <input type="text" id="name" name="name" class="text-gray-800 w-full px-3 py-2 border border-gray-300 rounded" required />
        </div>        
        
        <div class="mb-4">
            <label for="email" class="block text-gray-100">Correo:</label>
            <input type="email" id="email" name="email" class="text-gray-800 w-full px-3 py-2 border border-gray-300 rounded" required />
        </div>
                
        <div class="mb-4">
            <label for="password" class="block text-gray-100">Contraseña:</label>
            <input type="password" id="password " name="password" class="text-gray-800 px-3 py-2 border border-gray-300 rounded w-full" required>
        </div>


        <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded">Crear Usuario</button>
    </form>
</section>



<script>
function validateForm() {
    const name = document.querySelector('input[name="name"]').value.trim();
    const email = document.querySelector('input[name="email"]').value.trim();

    if (!name || !email) {
        alert("Ambos campos son obligatorios.");
        return false;
    }
    return true;
}
</script>
<div class="min-h-screen flex items-center justify-center bg-black">
  <div class="bg-black p-8 rounded shadow-md w-full max-w-sm border border-red-700/40">
    <h2 class="text-2xl font-bold mb-6 text-center text-gray-100">Iniciar sesión</h2>

    <form action="/login" method="POST" class="space-y-4">
      <div>
        <label for="email" class="block text-sm font-medium text-white-700">Correo electrónico</label>
        <input type="email" name="email" id="email" required
          class="text-gray-800 mt-1 block w-full px-4 py-2 border border-gray-800 rounded-md shadow-sm focus:outline-none focus:ring-red-500 focus:border-red-500">
      </div>

      <div>
        <label for="password" class="block text-sm font-medium text-white-700">Contraseña</label>
        <input type="password" name="password" id="password" required
          class="text-gray-800 mt-1 block w-full px-4 py-2 border border-gray-800 rounded-md shadow-sm focus:outline-none focus:ring-red-500 focus:border-red-500">
          <input type="hidden" name="redirect" value="<?= htmlspecialchars($redirect ?? '/') ?>">
      </div>

      <button type="submit"
        class="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-white-600 transition duration-200">
        Ingresar
      </button>
      
      

      <div class="flex items-center justify-center mt-4 space-x-2">
        <span class="text-gray-400">ó</span>
      </div>

      <div class="flex items-center justify-center mt-4">
        
        <a href="google-login?redirect=<?= urlencode($_GET['redirect'] ?? '/dashboard') ?>""
          class="w-full text-center bg-red-600 hover:bg-red-700 text-white font-semibold py-2 px-4 rounded-md transition duration-200">
          Iniciar sesión con Google
        </a>
      </div>

      <div class="flex items-center justify-center mt-4">
        <a href="createUser" class="text-center text-blue-400 hover:underline">Regístrate</a>
      </div>
    </form>
  </div>
</div>







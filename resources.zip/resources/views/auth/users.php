<br><br><br><br>

<section class="p-4">
    <div class="flex justify-between items-center mb-4">
        <a href="/createUser" class="bg-blue-700 hover:bg-blue-600 px-5 py-2 rounded-lg text-white transition">Agregar</a>
        <!-- Bot��n que solo se muestra en dispositivos peque�0�9os -->
<button id="toggleViewBtn" class="bg-gray-700 hover:bg-gray-600 px-4 py-2 rounded-lg text-white transition md:hidden">
    Cambiar vista
</button>
    </div>

    <h2 class="text-2xl font-bold mb-4 text-gray-800 dark:text-white">Lista de Usuarios</h2>

    <?php if (!empty($users)) : ?>
        <!-- Tabla horizontal -->
        <div id="user-table-wrapper" class="overflow-x-auto hidden md:block">
            <table id="user-table" class="table-auto min-w-full border border-gray-300 dark:border-gray-700 text-gray-800 dark:text-gray-100">
                <thead>
                    <tr class="bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-white">
                        <th class="px-4 py-2 border">ID</th>
                        <th class="px-4 py-2 border">Nombre</th>
                        <th class="px-4 py-2 border">Correo</th>
                        <th class="px-4 py-2 border">Creado en</th>
                        <th class="px-4 py-2 border text-center">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user) : ?>
                        <tr class="hover:bg-gray-100 dark:hover:bg-gray-800 transition">
                            <td class="border px-4 py-2"><?= htmlspecialchars($user['id']) ?></td>
                            <td class="border px-4 py-2"><?= htmlspecialchars($user['name']) ?></td>
                            <td class="border px-4 py-2"><?= htmlspecialchars($user['email']) ?></td>
                            <td class="border px-4 py-2"><?= htmlspecialchars($user['created_at']) ?></td>
                            <td class="border px-4 py-2 text-center space-x-3">
                                <a href="/editUser?id=<?= $user['id'] ?>" class="text-yellow-400 hover:text-yellow-300 transition" title="Editar">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <a href="/users/delete?id=<?= $user['id'] ?>" class="text-red-500 hover:text-red-400 transition" title="Eliminar" onclick="return confirm('�0�7Est��s seguro de eliminar este usuario?');">
                                    <i class="fas fa-trash-alt"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <!-- Tarjetas verticales -->
        <div id="user-cards" class="block md:hidden space-y-4 text-gray-900 dark:text-gray-100 hidden">
            <?php foreach ($users as $user) : ?>
                <div class="border p-4 rounded-md bg-white dark:bg-gray-800 dark:border-gray-600 shadow-md">
                    <p><span class="font-semibold">ID:</span> <?= htmlspecialchars($user['id']) ?></p>
                    <p><span class="font-semibold">Nombre:</span> <?= htmlspecialchars($user['name']) ?></p>
                    <p><span class="font-semibold">Correo:</span> <?= htmlspecialchars($user['email']) ?></p>
                    <p><span class="font-semibold">Creado en:</span> <?= htmlspecialchars($user['created_at']) ?></p>
                    <div class="flex justify-start space-x-4 mt-3">
                        <a href="/editUser/<?= $user['id'] ?>" class="text-yellow-500 hover:text-yellow-400 text-xl" title="Editar">
                            <i class="fas fa-edit"></i>
                        </a>
                        <a href="/users/delete/<?= $user['id'] ?>" class="text-red-500 hover:text-red-400 text-xl" title="Eliminar" onclick="return confirm('�0�7Est��s seguro de eliminar este usuario?');">
                            <i class="fas fa-trash-alt"></i>
                        </a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else : ?>
        <p class="text-gray-800 dark:text-gray-300">No hay usuarios registrados a��n.</p>
    <?php endif; ?>
</section>

<script>
    const tableWrapper = document.getElementById('user-table-wrapper');
    const cards = document.getElementById('user-cards');
    const toggleBtn = document.getElementById('toggleViewBtn');

    function applyView(view) {
        if (view === 'cards') {
            tableWrapper.classList.add('hidden');
            cards.classList.remove('hidden');
        } else {
            tableWrapper.classList.remove('hidden');
            cards.classList.add('hidden');
        }
    }

    function initView() {
        const savedView = localStorage.getItem('userView');

        if (savedView) {
            applyView(savedView);
        } else {
            // Auto detectar
            const shouldUseCards = document.getElementById('user-table').scrollWidth > tableWrapper.clientWidth;
            const defaultView = shouldUseCards ? 'cards' : 'table';
            localStorage.setItem('userView', defaultView);
            applyView(defaultView);
        }
    }

    toggleBtn.addEventListener('click', () => {
        const currentView = localStorage.getItem('userView') === 'cards' ? 'table' : 'cards';
        localStorage.setItem('userView', currentView);
        applyView(currentView);
    });

    window.addEventListener('load', initView);
    window.addEventListener('resize', () => {
        if (!localStorage.getItem('userView')) {
            initView();
        }
    });
</script>    
       
       
       
       
       
       
       
 
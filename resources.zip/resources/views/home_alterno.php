<section class="relative flex flex-col items-center justify-center overflow-hidden 
                min-h-screen bg-black text-white 
                px-4 sm:px-6 md:px-12 lg:px-20 xl:px-32 2xl:px-48">

  <!-- ########## SVG DE FONDO ########## -->
  <div class="absolute inset-0 -z-10 flex items-center justify-center">
    <svg viewBox="0 0 1440 900" preserveAspectRatio="xMidYMid meet"
         class="transition-all duration-700 ease-in-out
                w-[220%] sm:w-[160%] md:w-[120%] lg:w-full xl:w-[90%] 2xl:w-[80%]
                opacity-30">
      <rect width="1440" height="900" fill="url(#grad)" />
      <defs>
        <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stop-color="#06b6d4"/>
          <stop offset="100%" stop-color="#ef4444"/>
        </linearGradient>
      </defs>
    </svg>
  </div>

  <!-- ########## CONTENIDO ########## -->
  <div class="relative z-10 flex flex-col md:flex-row items-center gap-8 
              text-center md:text-left w-full max-w-7xl">

    <!-- Texto -->
    <div class="flex-1 px-4 md:px-6">
      <h1 class="text-3xl sm:text-4xl md:text-5xl lg:text-6xl xl:text-7xl 2xl:text-8xl font-bold mb-4">
        Adaptabilidad total
      </h1>
      <p class="text-gray-300 text-base sm:text-lg md:text-xl lg:text-2xl xl:text-3xl">
        Este dise&ntildeo responde a cada rango de pantalla con fluidez y elegancia.
      </p>
      <button class="mt-6 bg-gradient-to-r from-cyan-500 to-red-500 hover:opacity-90 
                     text-white font-semibold rounded-2xl px-6 py-3 
                     text-sm sm:text-base md:text-lg lg:text-xl transition-all">
        Empezar ahora
      </button>
    </div>

    <!-- Imagen o SVG decorativo adicional -->
    <div class="flex-1 flex items-center justify-center">
      <svg viewBox="0 0 1000 700" class="w-[80%] sm:w-[70%] md:w-[100%] lg:w-[50%] xl:w-[40%] 2xl:w-[35%]">
        <!-- circle cx="300" cy="200" r="150" fill="url(#grad2)" opacity="0.8"/ -->
        <defs>
          <linearGradient id="grad2" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="#06b6d4"/>
            <stop offset="100%" stop-color="#ef4444"/>
          </linearGradient>
        </defs>
        <path d="M0,0
                 L1000,0
                 L1000,1000
                 L0,1000
                 Z" fill="none" stroke="none" />
                 
        <path d="M160,220
                 Q200,200 200,200
                 Q400,70 400,70
                 Q700,90 700,90
                 Q850,200 850,200
                 Q890,550 890,550
                 Q780,670 780,670
                 Q400,700 400,700
                 Q100,600 100,600
                 Z" fill="#fff" stroke="none" stroke-width="4" />
              
        <path d="M280,170
                 L740,170
                 L740,470
                 L280,470
                 Z" fill="#000" stroke="#fff" stroke-width="4" />
                 
        <path d="M210,340
                 L350,340
                 L350,560
                 L210,560
                 Z" fill="#000" stroke="#fff" stroke-width="4" />
                 
        <path d="M510,340
                 L800,340
                 L800,560
                 L510,560
                 Z" fill="#000" stroke="#fff" stroke-width="4" />
      
      </svg>
    </div>

  </div>
</section>
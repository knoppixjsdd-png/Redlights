
<div class="max-w-6xl mx-auto px-4 py-16">
  <div class="flex items-center justify-center">
    <svg viewBox="0 0 1000 900" class="block w-full">
      <defs>
        <radialGradient id="whiteRedFade" cx="50%" cy="50%" r="50%">
           <!-- centro blanco -->
           <stop offset="0%" stop-color="#ffffff" stop-opacity="0.7"/>

           <!-- transición a rojo -->
           <stop offset="20%" stop-color="#ff0000" stop-opacity="0.4"/>

           <!-- rojo desvaneciéndose -->
           <stop offset="30%" stop-color="#770000" stop-opacity="0.5"/>

           <!-- totalmente transparente -->
           <stop offset="100%" stop-color="#ff0000" stop-opacity="0.01"/>
        </radialGradient>
        <pattern id="dotsResponsive" width="4" height="4" patternUnits="userSpaceOnUse">
          <circle cx="0.9" cy="0.9" r="1.5" fill="#f00" opacity="none"/>
        </pattern>
      </defs>
      
      <text font-family="Inter, Arial, sans-serif"
            text-anchor="middle"
            dominant-baseline="middle">
        <tspan x="420" y="330"
               font-weight="700"
               font-size="60"
               fill="#fff">
          Construimos experiencias
        </tspan>
        <tspan x="440" y="400"
               font-weight="700"
               font-size="60"
               fill="#fff">
          digitales con identidad
        </tspan>
        <tspan x="500" y="470"
               font-weight="300"
               font-size="40"
               fill="#fff">
          Diseño, tecnología y automatización
        </tspan>
        <tspan x="540" y="530"
               font-weight="300"
               font-size="40"
               fill="#fff">
          integrados en un solo sistema para
        </tspan>
        <tspan x="555" y="590"
               font-weight="300"
               font-size="40"
               fill="#fff">
          impulsar tu presencia digital.
        </tspan>
        
      </text>

      <!-- svg computadora -->
      <path d="M660,70 L670,70" fill="url(#whiteRedFade)" stroke="#f00" stroke-width="2"/>
      <path d="M680,70 L690,70" fill="none" stroke="#f00" stroke-width="2"/>
      <path d="M700,70 L710,70" fill="none" stroke="#f00" stroke-width="2"/>
      <path d="M720,70 L870,70" fill="none" stroke="#f00" stroke-width="2"/>
      <circle cx="780" cy="70" r="50" fill="url(#whiteRedFade)" opacity="none"/>
      
      <path d="M690,90 L700,90" fill="none" stroke="#f00" stroke-width="4"/>
      <path d="M700,90 L710,90" fill="none" stroke="#f00" stroke-width="1"/>
      <path d="M710,90 L720,90" fill="none" stroke="#f00" stroke-width="4"/>
      <path d="M720,90 L790,90" fill="none" stroke="#f00" stroke-width="1"/>
      <path d="M790,90 L800,90" fill="none" stroke="#f00" stroke-width="4"/>
      <path d="M800,90 L890,90 L950,40 L1000,40" fill="none" stroke="#f00" stroke-width="1"/>
      <circle cx="695" cy="90" r="20" fill="url(#whiteRedFade)" opacity="none"/>
      <circle cx="715" cy="90" r="20" fill="url(#whiteRedFade)" opacity="none"/>
      <circle cx="795" cy="90" r="20" fill="url(#whiteRedFade)" opacity="none"/>
      
      <path d="M750,100 L910,100 L958,60 1000,60" fill="none" stroke="#f00" stroke-width="1"/>
      
      <path d="M630,110 L640,110" fill="none" stroke="#f00" stroke-width="2"/>
      <path d="M650,110 L660,110" fill="none" stroke="#f00" stroke-width="2"/>
      <path d="M670,110 L680,110" fill="none" stroke="#f00" stroke-width="2"/>
      <path d="M690,110 L700,110" fill="none" stroke="#f00" stroke-width="2"/>
      <path d="M710,110 L720,110" fill="none" stroke="#f00" stroke-width="2"/>
      <path d="M730,110 L740,110" fill="none" stroke="#f00" stroke-width="2"/>
      <path d="M750,110 L760,110" fill="none" stroke="#f00" stroke-width="2"/>
      <path d="M770,110 L930,110 L966,80 1000,80" fill="none" stroke="#f00" stroke-width="1"/>
      <circle cx="635" cy="110" r="10" fill="url(#whiteRedFade)" />
      <circle cx="655" cy="110" r="10" fill="url(#whiteRedFade)" />
      <circle cx="675" cy="110" r="10" fill="url(#whiteRedFade)" />
      <circle cx="695" cy="110" r="10" fill="url(#whiteRedFade)" />
      <circle cx="715" cy="110" r="10" fill="url(#whiteRedFade)" />
      <circle cx="735" cy="110" r="10" fill="url(#whiteRedFade)" />
      <circle cx="755" cy="110" r="10" fill="url(#whiteRedFade)" />
      
      <path d="M350,160 L500,160 L550,145 L770,145 L810,125 L937,125 L970,100 1000,100" fill="none" stroke="#f00" stroke-width="1"/>
      <circle cx="350" cy="160" r="40" fill="url(#whiteRedFade)" />
      <circle cx="937" cy="125" r="40" fill="url(#whiteRedFade)" />
      
      <path d="M570,170 L730,170 L780,210 L850,210 L890,170 L1000,170" fill="none" stroke="#f00" stroke-width="1"/>
      <circle cx="700" cy="170" r="40" fill="url(#whiteRedFade)" />
      <circle cx="900" cy="170" r="40" fill="url(#whiteRedFade)" />
      
      
      
      <path d="M20,650 L160,650 L220,700 L400,700" fill="none" stroke="#f00" stroke-width="1"/>
      <circle cx="160" cy="650" r="45" fill="url(#whiteRedFade)" />
      <circle cx="400" cy="700" r="45" fill="url(#whiteRedFade)" />
      
      <path d="M20,670 L150,670 L210,720 L350,720" fill="none" stroke="#f00" stroke-width="1"/>
      <path d="M360,720 L370,720" fill="none" stroke="#f00" stroke-width="1"/>
      <path d="M380,720 L390,720" fill="none" stroke="#f00" stroke-width="1"/>
      <path d="M400,720 L410,720" fill="none" stroke="#f00" stroke-width="1"/>
      <path d="M420,720 L430,720" fill="none" stroke="#f00" stroke-width="1"/>
      <path d="M440,720 L450,720" fill="none" stroke="#f00" stroke-width="1"/>
      <path d="M460,720 L470,720" fill="none" stroke="#f00" stroke-width="1"/>
      <circle cx="365" cy="720" r="10" fill="url(#whiteRedFade)" />
      <circle cx="385" cy="720" r="10" fill="url(#whiteRedFade)" />
      <circle cx="405" cy="720" r="10" fill="url(#whiteRedFade)" />
      <circle cx="425" cy="720" r="10" fill="url(#whiteRedFade)" />
      <circle cx="445" cy="720" r="10" fill="url(#whiteRedFade)" />
      <circle cx="465" cy="720" r="10" fill="url(#whiteRedFade)" />
      
      <path d="M20,690 L140,690 L200,740 L350,740" fill="none" stroke="#f00" stroke-width="1"/> 
      <circle cx="200" cy="740" r="40" fill="url(#whiteRedFade)" opacity="none"/>
      
      <path d="M20,820 L140,820 L250,770 L450,770" fill="none" stroke="#f00" stroke-width="1"/>
      <circle cx="140" cy="820" r="40" fill="url(#whiteRedFade)" />
      <circle cx="450" cy="770" r="40" fill="url(#whiteRedFade)" />
      
      
      <path d="M20,840 L140,840 L250,790 L750,790" fill="none" stroke="#f00" stroke-width="1"/>
      <circle cx="250" cy="790" r="40" fill="url(#whiteRedFade)" />
      <circle cx="750" cy="790" r="45" fill="url(#whiteRedFade)" />
      <circle cx="750" cy="790" r="20" fill="#f00" opacity="none"/>
      <circle cx="750" cy="790" r="17" fill="#000" opacity="none"/>
      
      
      
    </svg>
  </div>
</div>











<!-- ========================================================= -->
<!-- ======================= RESPONSIVE ====================== -->
<!-- ========================================================= -->
<div class="py-14">
<div class="transition-transform duration-300 hover:scale-[1.02]">
<div class="max-w-[420px] mx-auto my-10 p-7 rounded-2xl border-[2px] border-red-700/35">

  <div class="flex items-center justify-center">
    <svg viewBox="0 0 1000 900" class="block w-full">
      <defs>
        <pattern id="dotsResponsive" width="4" height="4" patternUnits="userSpaceOnUse">
          <circle cx="0.9" cy="0.9" r="1.5" fill="#f00" opacity="none"/>
        </pattern>
      </defs>

      <text font-family="Inter, Arial, sans-serif"
            text-anchor="middle"
            dominant-baseline="middle">
        <tspan x="500" y="200"
               font-weight="700"
               font-size="48"
               fill="#fff">
          RESPONSIVE
        </tspan>
      </text>

      <!-- svg computadora -->
      <path d="M394.4,409.2 Q394.4,399.6 404,399.6 L605.6,399.6 Q615.2,399.6 615.2,409.2 L615.8,543.6 L394.4,543.6 Z"
            fill="#000" stroke="#f00" stroke-width="3"/>
      <path d="M404,409.2 L604.6,409.2 L604.6,459.6 L404,459.6 Z"
            fill="url(#dotsResponsive)"/>
      <path d="M404,469.2 L465.6,469.2 L465.6,531 L404,531 Z"
            fill="url(#dotsResponsive)"/>
      <path d="M473.6,469.2 L537.6,469.2 L537.6,531 L473.6,531 Z"
            fill="url(#dotsResponsive)"/>
      <path d="M544.6,469.2 L605.6,469.2 L605.6,531 L544.6,531 Z"
            fill="url(#dotsResponsive)"/>

      <!-- celular -->
      <path d="M360.8,520.8 Q360.8,511.8 370.4,511.2 L418.4,511.2 Q428,511.2 428,520.8 L428,607.2 Q428,616.8 418.4,616.8 L370.4,616.8 Q360.8,616.8 360.8,607.2 Z"
            fill="#000" stroke="#f00" stroke-width="3"/>
      <path d="M371,521 L418,521 L418,560 L371,560 Z"
            fill="url(#dotsResponsive)"/>
      <path d="M371,570 L418,570 L418,605 L371,605 Z"
            fill="url(#dotsResponsive)"/>

      <!-- tablet -->
      <path d="M528.8,520.8 Q528.8,511.2 538.4,511.2 L652.4,511.2 Q662,511.2 662,520.8 L662,607.2 Q662,616.8 652.4,616.8 L538.4,616.8 Q528.8,616.8 528.8,607.2 Z"
            fill="#000" stroke="#f00" stroke-width="3"/>
      <path d="M540,521 L650,521 L650,560 L540,560 Z"
            fill="url(#dotsResponsive)"/>
      <path d="M540,570 L591,570 L591,605 L540,605 Z"
            fill="url(#dotsResponsive)"/>
      <path d="M599,570 L650,570 L650,605 L599,605 Z"
            fill="url(#dotsResponsive)"/>
    </svg>
  </div>

  <p class="leading-relaxed tracking-wide mt-4 text-justify">
    Tu sitio se adapta perfectamente a celulares, tablets y computadoras.
Ofrece una experiencia profesional sin importar desde dónde te visiten.
  </p>

</div>
</div>
</div>
<!-- ========================================================= -->
<!-- =========================== CMS ========================= -->
<!-- ========================================================= -->

<div class="transition-transform duration-300 hover:scale-[1.02]">
<div class="max-w-[420px] mx-auto my-10 p-7 rounded-2xl border-2 border-red-700/35">

  <div class="flex items-center justify-center">
    <svg viewBox="0 0 1000 700" class="block w-full">
      <defs>
        <pattern id="dotsCMS" width="4" height="4" patternUnits="userSpaceOnUse">
          <circle cx="0.9" cy="0.9" r="1.5" fill="#f00" opacity="none"/>
        </pattern>
      </defs>

      <text font-family="Inter, Arial, sans-serif"
            text-anchor="middle"
            dominant-baseline="middle">
        <tspan x="500" y="200"
               font-weight="700"
               font-size="48"
               fill="#fff">
          SISTEMA GESTOR DE CONTENIDOS
        </tspan>
      </text>

      <!-- engrane -->
      <path d="M632,440 L632,410 L662,410 L662,440
               L679.5,447.3 L700.7,426.0 L722.0,447.3 L700.7,468.5
               L708,486 L738,486 L738,516 L708,516
               L700.7,533.5 L722.0,554.7 L700.7,576.0 L679.5,554.7
               L662,563 L662,592 L632,592 L632,563
               L613.8,555.4 L593.3,576.0 L572.0,554.7 L592.6,534.2
               L586,516 L556,516 L556,486 L586,486
               L593.3,468.5 L572.0,447.3 L593.3,426.0 L614.5,447.3 Z"
            fill="url(#dotsCMS)" stroke="#f00" stroke-width="3"/>

      <circle cx="646.9" cy="501" r="45" fill="#000" stroke="#f00" stroke-width="4"/>
      <circle cx="646.9" cy="501" r="35" fill="url(#dotsCMS)" stroke="#f00" stroke-width="4"/>
      <circle cx="646.9" cy="501" r="25" fill="#000" stroke="#f00" stroke-width="4"/>

      <!-- pantalla -->
      <path d="M394.4,409.2 Q394.4,399.6 404,399.6 L605.6,399.6 Q615.2,399.6 615.2,409.2 L615.8,440 L394.4,440 Z"
            fill="#000" stroke="#f00" stroke-width="3"/>
      <path d="M394.4,409.2 Q394.4,399.6 404,399.6 L605.6,399.6 Q615.2,399.6 615.2,409.2 L615.8,440 L394.4,440 Z"
            fill="url(#dotsCMS)" stroke="#f00" stroke-width="3"/>
      <path d="M394.4,455 L615.8,455 L615.8,600 L394.4,600 Z"
            fill="#000" stroke="#f00" stroke-width="3"/>
      <path d="M394.4,455 L615.8,455 L615.8,600 L394.4,600 Z"
            fill="url(#dotsCMS)" stroke="#f00" stroke-width="3"/>
    </svg>
  </div>

  <p class="leading-relaxed tracking-wide mt-4 text-justify">
    Administra textos, imágenes y productos sin depender de un programador.
Control total de tu contenido en pocos clicks.
  </p>

</div>
</div>

<!-- ========================================================= -->
<!-- ========================== REDES ======================== -->
<!-- ========================================================= -->

<div class="transition-transform duration-300 hover:scale-[1.02]">
<div class="max-w-[420px] mx-auto my-10 p-7 rounded-2xl border-2 border-red-700/35">

  <div class="flex items-center justify-center">
    <svg viewBox="0 0 1000 700" class="block w-full">
      <defs>
        <pattern id="dotsSocial" width="4" height="4" patternUnits="userSpaceOnUse">
          <circle cx="0.9" cy="0.9" r="1.5" fill="#f00" opacity="none"/>
        </pattern>
      </defs>

      <text font-family="Inter, Arial, sans-serif"
            text-anchor="middle"
            dominant-baseline="middle">
        <tspan x="500" y="200"
               font-weight="700"
               font-size="48"
               fill="#fff">
          REDES
        </tspan>
      </text>

      <circle cx="500" cy="500" r="140" fill="url(#dotsSocial)" stroke="#f00" stroke-width="4"/>
      <circle cx="500" cy="500" r="125" fill="#000" stroke="#f00" stroke-width="4"/>
      <circle cx="500" cy="500" r="110" fill="url(#dotsSocial)" stroke="#f00" stroke-width="4"/>
      
      <circle cx="527" cy="457" r="24" fill="#f00" stroke="none" stroke-width="4" />  
<circle cx="450" cy="500" r="24" fill="#f00" stroke="none" stroke-width="4" />  
<circle cx="527" cy="543" r="24" fill="#f00" stroke="none" stroke-width="4" />  
<path d="M450,500 L530,455 Z" fill="#000" stroke="#f00" stroke-width="20"  />  
<path d="M450,500 L530,455 Z" fill="#000" stroke="#000" stroke-width="13"  />  
<path d="M450,500 L530,545 Z" fill="#000" stroke="#f00" stroke-width="20"  />  
<path d="M450,500 L530,545 Z" fill="#000" stroke="#000" stroke-width="13"  />  
<circle cx="527" cy="457" r="20" fill="#000" stroke="none" stroke-width="4" />  
<circle cx="450" cy="500" r="20" fill="#000" stroke="none" stroke-width="4" />  
<circle cx="527" cy="543" r="20" fill="#000" stroke="none" stroke-width="4" />
    </svg>
  </div>

  <p class="leading-relaxed tracking-wide mt-4 text-justify">
    Conecta tu marca con tus redes sociales para aumentar visibilidad, tráfico y ventas desde un solo lugar.
  </p>

</div>
</div>

<!-- ========================================================= -->
<!-- =========================== MAIL ======================== -->
<!-- ========================================================= -->

<div class="transition-transform duration-300 hover:scale-[1.02]">
<div class="max-w-[420px] mx-auto my-10 p-7 rounded-2xl border-2 border-red-700/35">

  <div class="flex items-center justify-center">
    <svg viewBox="0 0 1000 700" class="block w-full">
      <defs>
        <pattern id="dotsMail" width="4" height="4" patternUnits="userSpaceOnUse">
          <circle cx="0.9" cy="0.9" r="1.5" fill="#f00" opacity="none"/>
        </pattern>
      </defs>

      <text font-family="Inter, Arial, sans-serif"
            text-anchor="middle"
            dominant-baseline="middle">
        <tspan x="500" y="200"
               font-weight="700"
               font-size="48"
               fill="#fff">
          MAIL
        </tspan>
      </text>

      <!-- sobre -->
      <rect x="300" y="340"
            width="400" height="250"
            rx="30" ry="30"
            fill="url(#dotsMail)"
            stroke="#f00"
            stroke-width="4"/>
      <path d="M305,350 L500,490 L690,350"
            fill="none" stroke="#f00" stroke-width="4"/>
    </svg>
  </div>

  <p class="leading-relaxed tracking-wide mt-4 text-justify">
    Recibe mensajes, cotizaciones y clientes directamente en tu correo profesional de forma automática y segura.
  </p>

</div>
</div>











<div class="flex justify-center my-6 w-full px-4">

  <a href="login"
     class="group relative w-full max-w-[320px]
            inline-flex items-center justify-center
            px-6 py-4
            font-semibold tracking-wide
            text-red-500
            border border-red-600/70
            rounded-xl
            bg-black
            overflow-hidden
            transition-all duration-300
            hover:text-white
            hover:border-red-500
            hover:scale-[1.03]
            active:scale-[0.97]
            hover:shadow-[0_0_25px_rgba(255,0,0,0.4)]">
    Reg&iacutestrate 
  </a>

</div>

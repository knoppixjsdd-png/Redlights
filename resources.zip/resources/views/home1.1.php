<div class="flex-1 flex items-center justify-center">

  <!-- ########## SVG PARA MÓVILES ########## -->
  <svg viewBox="0 -1000 1000 8450" class="block md:hidden w-[100%] sm:w-[100%] md:w-[100%] lg:w-[50%] xl:w-[40%] 2xl:w-[35%]">
    <defs>
      <linearGradient id="grad1" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" stop-color="red"/>
        <stop offset="100%" stop-color="#000"/>
      </linearGradient>
      
      <pattern id="microDots" width="4" height="4" patternUnits="userSpaceOnUse">
        <circle cx="0.9" cy="0.9" r="1.5" fill="#f00" opacity="none" />
      </pattern>
    </defs>
    
    <text font-family="Inter, Arial, sans-serif"
          stroke-width="1"
          text-anchor="start"
          dominant-baseline="middle">
            <tspan x="280" y="200"
                   font-weight="700"
                   font-size="48"
                   fill="#fff"
                   stroke="none" >
               DISEÑO RESPONSIVO
             </tspan>
    </text>

    <!-- svg computadora -->
    <path d="M394.4,409.2
             Q394.4,399.6 404,399.6
             L605.6,399.6
             Q615.2,399.6 615.2,409.2
             L615.8,543.6
             L394.4,543.6
             Z" 
             fill="#000" stroke="#f00" stroke-width="3"  />
   
    <path d="M404,409.2
         L604.6,409.2
         L604.6,459.6
         L404,459.6
         Z" 
         fill="url(#microDots)" stroke="none" />
         
    <path d="M404,469.2
         L465.6,469.2
         L465.6,531
         L404,531
         Z" 
         fill="url(#microDots)" stroke="none" />
         
    <path d="M473.6,469.2
         L537.6,469.2
         L537.6,531
         L473.6,531
         Z" 
         fill="url(#microDots)" stroke="none" />
         
    <path d="M544.6,469.2
         L605.6,469.2
         L605.6,531
         L544.6,531
         Z" 
         fill="url(#microDots)" stroke="none" />
         
    <!-- svg celular -->
    <path d="M360.8,520.8
             Q360.8,511.8 370.4,511.2
             L418.4,511.2
             Q428,511.2 428,520.8
             L428,607.2
             Q428,616.8 418.4,616.8
             L370.4,616.8
             Q360.8,616.8 360.8,607.2
             Z" 
             fill="#000" stroke="#f00" stroke-width="3" />
    
    <path d="M371,521
         L418,521
         L418,560
         L371,560
         Z" 
         fill="url(#microDots)" stroke="none" />
    
    <path d="M371,570
         L418,570
         L418,605
         L371,605
         Z" 
         fill="url(#microDots)" stroke="none" />
    
    <!-- svg tablet -->
    <path d="M528.8,520.8
             Q528.8,511.2 538.4,511.2
             L652.4,511.2
             Q662,511.2 662,520.8
             L662,607.2
             Q662,616.8 652.4,616.8
             L538.4,616.8
             Q528.8,616.8 528.8,607.2
             Z" 
             fill="#000" stroke="#f00" stroke-width="3" />
  
    <path d="M540,521
         L650,521
         L650,560
         L540,560
         Z" 
         fill="url(#microDots)" stroke="none" />
    
    <path d="M540,570
         L591,570
         L591,605
         L540,605
         Z" 
         fill="url(#microDots)" stroke="none" />
    
    <path d="M599,570
         L650,570
         L650,605
         L599,605
         Z" 
         fill="url(#microDots)" stroke="none" />
    
    
    <text font-family="Inter, Arial, sans-serif"
      stroke-width="1"
      text-anchor="start"
      dominant-baseline="middle">

        <tspan x="90" y="850"
               font-weight="300"
               font-size="44"
               fill="#fff"
               stroke="none"
               textLength="820"
               lengthAdjust="spacing">
          Sitios creados para todos tus dispositivos,
        </tspan>

        <tspan x="90" y="900"
               font-weight="300"
               font-size="44"
               fill="#fff"
               stroke="none"
               textLength="820"
               lengthAdjust="spacing">
          no importa desde donde lo veas, tu página
        </tspan>
        
        <tspan x="90" y="950"
               font-weight="300"
               font-size="44"
               fill="#fff"
               stroke="none"
               textLength="820"
               lengthAdjust="spacing">
          siempre lucirá impecable gracias a nuestro
        </tspan>
        
        <tspan x="90" y="1000"
               font-weight="300"
               font-size="44"
               fill="#fff"
               stroke="none"
               textLength="820"
               lengthAdjust="spacing">
          diseño que se adapta al tamaño de tu pantalla 
        </tspan>
    </text>
  </svg>

  <!-- ########## SVG PARA ESCRITORIO ########## -->
  <svg viewBox="0 0 1000 450" class="hidden md:block w-[100%] sm:w-[70%] md:w-[100%] lg:w-[50%] xl:w-[40%] 2xl:w-[35%]">
    <defs>
      <linearGradient id="grad2" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" stop-color="#000"/>
        <stop offset="50%" stop-color="#012e46"/>
        <stop offset="100%" stop-color="#000"/>
      </linearGradient>
    </defs>

             
    <!-- Versi車n para escritorio -->
    
    <path d="M0,0 
             L1000,0
             L1000,480
             L0,480
             Z" 
             fill="url(#grad2)" 
             opacity="0.95"
             class="hidden md:block" />
      
    <path d="M640,165
             L870,165
             L870,315
             L640,315
             Z" fill="#000" stroke="#fff" stroke-width="2" 
             class="hidden md:block" />

    <path d="M605,250
             L675,250
             L675,360
             L605,360
             Z" fill="#000" stroke="#fff" stroke-width="2" 
             class="hidden md:block" />

    <path d="M755,230
             L900,230
             L900,360
             L755,360
             Z" fill="#000" stroke="#fff" stroke-width="2" 
             class="hidden md:block" />
  
  </svg>

</div>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Blog RedLights</title>
  <script src="https://cdn.tailwindcss.com"></script><style>
    .text-turquoise-400 { color: #40E0D0; }
    .text-turquoise-300 { color: #48D1CC; }
    .line-clamp-3 {
      display: -webkit-box;
      -webkit-line-clamp: 3;
      -webkit-box-orient: vertical;
      overflow: hidden;
    }
  </style>
</head>
<body class="bg-gray-500 text-white font-sans min-h-screen flex flex-col">

  <!-- Header -->
  <header class="bg-gray-900 fixed w-full top-0 left-0 z-50 shadow-lg">
    <div class="max-w-7xl mx-auto flex items-center justify-between px-6 py-4">
      <a href="#" class="text-3xl font-bold text-white hover:text-white transition-colors">RedLights</a>
      <nav>
        <ul class="flex space-x-8 text-lg">
          <li><a href="#" class="hover:text-turquoise-400 transition-colors">Inicio</a></li>
          <li><a href="#" class="text-turquoise-400 font-semibold">Blog</a></li>
          <li><a href="#" class="hover:text-turquoise-400 transition-colors">Contacto</a></li>
          <li><a href="#" class="hover:text-turquoise-400 transition-colors">Sobre mí</a></li>
        </ul>
      </nav>
    </div>
  </header>

  <div class="h-20"></div>

  <!-- Main -->
  <main class="flex-grow max-w-7xl mx-auto px-6 py-12">
    <h1 class="text-5xl font-bold mb-12 text-White drop-shadow-lg">Blog RedLights</h1>

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
      <!-- Tarjeta de blog -->
      <article class="bg-gray-900 rounded-lg shadow-lg overflow-hidden hover:shadow-red-600 transition-shadow duration-300 cursor-pointer">
        <a href="#" class="block">
          <img src="https://picsum.photos/600/400?random=1" alt="Post 1" class="w-full h-48 object-cover hover:scale-105 transition-transform duration-300" />
          <div class="p-6">
            <h2 class="text-2xl font-semibold mb-2 text-turquoise-400 hover:text-turquoise-300 transition-colors duration-200">Inspiración Digital</h2>
            <p class="text-gray-300 line-clamp-3">Descubre cómo una buena interfaz puede aumentar tus ventas y mejorar la percepción de tu marca.</p>
            <time class="block mt-4 text-sm text-gray-500">30 Jun 2025</time>
          </div>
        </a>
      </article>

      <!-- Otra tarjeta -->
      <article class="bg-gray-900 rounded-lg shadow-lg overflow-hidden hover:shadow-red-600 transition-shadow duration-300 cursor-pointer">
        <a href="#" class="block">
          <img src="https://picsum.photos/600/400?random=2" alt="Post 2" class="w-full h-48 object-cover hover:scale-105 transition-transform duration-300" />
          <div class="p-6">
            <h2 class="text-2xl font-semibold mb-2 text-turquoise-400 hover:text-turquoise-300">Diseño que impacta</h2>
            <p class="text-gray-300 line-clamp-3">No basta con tener un sitio bonito: necesitas uno que funcione, que hable por ti y que enamore al cliente.</p>
            <time class="block mt-4 text-sm text-gray-500">28 Jun 2025</time>
          </div>
        </a>
      </article>

      <!-- Otra tarjeta -->
      <article class="bg-gray-900 rounded-lg shadow-lg overflow-hidden hover:shadow-red-600 transition-shadow duration-300 cursor-pointer">
        <a href="#" class="block">
          <img src="https://picsum.photos/600/400?random=3" alt="Post 3" class="w-full h-48 object-cover hover:scale-105 transition-transform duration-300" />
          <div class="p-6">
            <h2 class="text-2xl font-semibold mb-2 text-turquoise-400 hover:text-turquoise-300">RedLights: Filosofía Visual</h2>
            <p class="text-gray-300 line-clamp-3">Un enfoque oscuro, elegante y con luz propia. Así se construye una marca que nadie olvida.</p>
            <time class="block mt-4 text-sm text-gray-500">25 Jun 2025</time>
          </div>
        </a>
      </article>
    </div>
  </main>

  <!-- Footer -->
  <footer class="bg-gray-900 text-gray-400 text-center py-6 mt-12 border-t border-gray-800">
    <p>© 2025 RedLights. Todos los derechos reservados.</p>
    <p class="mt-1">Diseñado con pasión por Jhovany & ChatGPT</p>
  </footer>

</body>
</html>
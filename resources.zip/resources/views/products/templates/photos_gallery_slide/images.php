<section class="max-w-6xl mx-auto py-12 px-4 grid gap-10 sm:grid-cols-1 md:grid-cols-2">
  <!-- Template para PC -->
  <div class="bg-slate-900 border border-white/10 backdrop-blur-md rounded-2xl shadow-2xl p-6 hover:shadow-red-500/40 transition">
    <h2 class="text-white text-2xl font-semibold mb-4 text-center drop-shadow">Glassmorphismo para PC</h2>
    
    <div class="rounded-xl overflow-hidden border border-white/10 mb-4">
      <img src="/images/images_templates/gifs/gif_pc/Photo album carousel.gif" alt="Preview PC" class="w-full h-[550px] object-cover">
    </div>
    
    <p class="text-gray-300 text-sm mb-2 text-center">Tipo: Sitio web de escritorio</p>
    <ul class="text-gray-400 text-sm space-y-1 text-center">
      <li>🖥️ Diseño pensado para pantallas grandes</li>
      <li>💎 Estilo moderno con efecto glass</li>
      <li>⚙️ Preparado para integración con PHP</li>
    </ul>

    <!--a href="#" class="mt-5 block bg-red-600 hover:bg-red-700 text-white font-semibold py-2 px-4 rounded-xl text-center transition"-->
      Ver demo
    </a>
  </div>

  <!-- Template para móvil -->
  <div class="bg-slate-900 border border-white/10 backdrop-blur-md rounded-2xl shadow-2xl p-6 hover:shadow-cyan-500/40 transition">
    <h2 class="text-white text-2xl font-semibold mb-4 text-center drop-shadow">Versión Responsive</h2>
    
    <div class="rounded-xl overflow-hidden border border-white/10 mb-4">
      <img src="/images/images_templates/gifs/gif_responsive/Photo album carousel.gif" alt="Preview móvil" class="w-full h-[550px] object-cover">
    </div>
    
    <p class="text-gray-300 text-sm mb-2 text-center">Tipo: Landing Page para celular</p>
    <ul class="text-gray-400 text-sm space-y-1 text-center">
      <li>📱 Diseño adaptable a cualquier pantalla</li>
      <li>🎯 Ideal para presentación de apps o productos</li>
      <li>⚡ Carga rápida y navegación fluida</li>
    </ul>

    <!--a href="#" class="mt-5 block bg-red-600 hover:bg-red-700 text-white font-semibold py-2 px-4 rounded-xl text-center transition"-->
      Ver demo
    </a>
  </div>
</section>
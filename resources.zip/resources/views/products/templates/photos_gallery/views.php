<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>redLights() - Galería por Categorías</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-br from-white via-gray-100 to-white min-h-screen text-gray-900">

<header class="bg-gray-500 backdrop-blur-md border-b border-blue-400">
    <div class="max-w-6xl mx-auto p-4 flex justify-between items-center">
      <h1 class="text-xl text-white font-bold">redLights ( )</h1>
      <nav>
        <ul class="flex gap-6 text-sm text-white/80">
          <li><a href="#inicio" class="hover:text-white transition">Inicio</a></li>
          <li><a href="#servicios" class="hover:text-white transition">Servicios</a></li>
          <li><a href="#contacto" class="hover:text-white transition">Contacto</a></li>
        </ul>
      </nav>
    </div>
  </header>
  
  <!-- Logo -->
  <div class="text-center py-10">
    <h1 class="text-5xl font-extrabold bg-gradient-to-r from-gray-400 via-gray-900 to-gray-400 text-transparent bg-clip-text">redLights()</h1>
    <p class="text-gray-900 mt-2 text-lg">Galería dividida por categorías</p>
  </div>

  <?php
  $galeria = [
    'Plantillas Web' => [
      ['titulo' => 'Landing Page', 'descripcion' => 'Diseño limpio para landing.', 'src' => 'https://picsum.photos/800/600?random=1'],
      ['titulo' => 'Ecommerce', 'descripcion' => 'Plantilla para tienda.', 'src' => 'https://picsum.photos/800/600?random=2'],
      ['titulo' => 'Internacionales', 'descripcion' => 'Ejecutivo', 'src' => 'https://picsum.photos/800/600?random=3'],
    ],
    
    
    'Logos' => [
      ['titulo' => 'Logo Tech', 'descripcion' => 'Estilo futurista.', 'src' => 'https://picsum.photos/800/600?random=4'],
      ['titulo' => 'Logo Creativo', 'descripcion' => 'Diseño artístico.', 'src' => 'https://picsum.photos/800/600?random=5'],
    ],
    
    
    'Promocionales' => [
      ['titulo' => 'Banner Oferta', 'descripcion' => 'Ideal para descuentos.', 'src' => 'https://picsum.photos/800/600?random=6'],
      ['titulo' => 'Anuncio App', 'descripcion' => 'Promoción de apps móviles.', 'src' => 'https://picsum.photos/800/600?random=7'],
    ]
  ];
  ?>

  <?php foreach ($galeria as $categoria => $imagenes): ?>
    <div class="max-w-7xl mx-auto px-8 py-8 bg-gray-300 mb-8 rounded-xl">
      <h2 class="text-2xl font-bold mb-4 border-b border-gray-600 pb-2"><?= $categoria ?></h2>
      <div class="grid gap-6 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
        <?php foreach ($imagenes as $img): ?>
          <div class="bg-gray-800 rounded-xl overflow-hidden shadow-lg border border-gray-700 hover:scale-105 transition">
            <img src="<?= $img['src'] ?>" alt="<?= $img['titulo'] ?>" class="w-full h-48 object-cover aspect-video cursor-pointer"
                 onclick="openModal('<?= $img['src'] ?>', '<?= addslashes($img['titulo']) ?>', '<?= addslashes($img['descripcion']) ?>')">
            <div class="p-4">
              <h3 class="text-white font-semibold text-lg"><?= $img['titulo'] ?></h3>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  <?php endforeach; ?>

  <!-- Modal -->
  <div id="modal" class="fixed inset-0 bg-black bg-opacity-80 hidden items-center justify-center z-50 flex-col text-center p-4 transition-all duration-600">
    <img id="modal-img" src="" class="max-h-[90vh] max-w-[95vw] w-auto h-auto rounded-xl shadow-2xl border border-white mb-6" />
    <h3 id="modal-title" class="text-white text-2xl font-semibold mb-2"></h3>
    <p id="modal-desc" class="text-white/80 max-w-3xl text-base mx-auto"></p>
    <button onclick="closeModal()" class="absolute top-5 right-5 text-white text-3xl font-bold">&times;</button>
  </div>
  
  
      <!-- Formulario decorativo -->
<section class="max-w-4xl mx-auto mt-20 px-6">
  <div class="bg-white rounded-2xl shadow-lg p-8 sm:p-12">
    <h3 class="text-3xl font-semibold text-gray-800 mb-6 text-center">Contáctame</h3>
    <form class="space-y-6">
      <div class="grid sm:grid-cols-2 gap-4">
        <input type="text" placeholder="Tu nombre" class="w-full p-3 border border-gray-300 rounded-lg focus:outline-none" disabled />
        <input type="email" placeholder="Tu correo" class="w-full p-3 border border-gray-300 rounded-lg focus:outline-none" disabled />
      </div>
      <textarea rows="4" placeholder="Escribe tu mensaje..." class="w-full p-3 border border-gray-300 rounded-lg focus:outline-none resize-none" disabled></textarea>
      <div class="text-center">
        <button type="button" class="bg-gray-300 text-gray-600 px-6 py-3 rounded-lg cursor-not-allowed opacity-60">
          Enviar mensaje (solo diseño)
        </button>
      </div>
    </form>
  </div>
</section>

  <script>
    function openModal(src, titulo, descripcion) {
      document.getElementById('modal-img').src = src;
      document.getElementById('modal-title').textContent = titulo;
      document.getElementById('modal-desc').textContent = descripcion;
      document.getElementById('modal').classList.remove('hidden');
      document.getElementById('modal').classList.add('flex');
    }

    function closeModal() {
      document.getElementById('modal').classList.remove('flex');
      document.getElementById('modal').classList.add('hidden');
    }
  </script>
  
  <!-- Footer -->
  <footer class="bg-gray-500 mt-9 backdrop-blur-md border-t border-white/20 p-4 text-center text-xs text-white/60">
    &copy; 2025 redLights(). Todos los derechos reservados.
  </footer>

</body>
</html>
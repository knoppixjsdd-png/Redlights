<div class="py-9"></div>

<section class="max-w-9xl mx-auto py-9 px-4">
  <h1 class="text-3xl sm:text-4xl font-bold text-white text-center mb-10">
    <?= $title ?? 'Cat�logo de Templates' ?>
  </h1>

  <div class="grid gap-6 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
    <?php foreach ($templates as $template): ?>
      <div class="bg-slate-900 rounded-2xl shadow-lg p-4 sm:p-6 backdrop-blur-md border border-gray-700">
        <h2 class="text-white text-xl font-semibold mb-2"><?= $template['name'] ?></h2>

        <div class="mb-4 rounded-xl overflow-hidden border border-white/10">
          <!-- Imagen para dispositivos m�viles -->
          <img src="/images/images_templates/pre_view/responsive/<?= $template['name'] ?>.jpg"
               alt="Imagen m�vil"
               class="block md:hidden w-[300px] h-[400px] rounded-xl shadow-lg object-cover" />

          <!-- Imagen para pantallas medianas en adelante -->
          <img src="/images/images_templates/pre_view/pc/<?= $template['name'] ?>.jpg"
               alt="Imagen escritorio"
               class="hidden md:block w-[405px] h-[300px] rounded-xl shadow-lg object-cover" />
        </div>

        <?php if ($template['purchased']): ?>
          <a href="templates/img_glassmorphisim_1">
            <button class="bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-xl w-full transition">
              Descargar
            </button>
          </a>
        <?php elseif (isset($_SESSION['role']) && $_SESSION['role'] === 'user'): ?>
          <a href="templates/<?= $template['file_path'] ?>/images">
            <button class="bg-cyan-700 hover:bg-cyan-900 py-2 px-4 rounded-xl w-full text-white font-medium transition">
              Ver
            </button>
          </a>

          <button onclick="openPaymentModal('<?= $template['id'] ?>')"
                  class="bg-red-600 hover:bg-red-700 text-white font-medium py-2 px-4 mt-4 rounded-xl w-full transition">
            Comprar $<?= number_format($template['price'], 2) ?>
          </button>

        <?php elseif (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
          <a href="templates/<?= $template['file_path'] ?>/views">
            <button class="bg-cyan-700 hover:bg-cyan-900 py-2 px-4 rounded-xl w-full text-white font-medium transition">
              Ver
            </button>
          </a>
        <?php else: ?>
          <a href="/login?redirect=<?= urlencode($_SERVER['REQUEST_URI']) ?>">
            <button class="bg-cyan-700 hover:bg-cyan-900 text-white font-medium py-2 px-4 rounded-xl w-full transition">
              Iniciar sesi&oacuten para comprar
            </button>
          </a>
        <?php endif; ?>
      </div>
    <?php endforeach; ?>
  </div>
</section>

<!-- Modal flotante -->
<div id="payment-modal" class="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 hidden">
  <div class="bg-gray-900 rounded-2xl p-6 w-full max-w-md shadow-2xl relative">
    <button id="close-modal" class="absolute top-2 right-3 text-white text-2xl">&times;</button>
    <h2 class="text-xl font-bold text-white mb-4">Pagar con tarjeta</h2>

    <form id="payment-form">
      <div id="card-element" class="p-4 bg-white rounded-md"></div>
      <button id="submit" class="mt-4 w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg">
        Pagar ahora
      </button>
      <div id="payment-result" class="mt-4 text-white font-medium"></div>
    </form>
  </div>
</div>

<script>
  function openPaymentModal(templateId) {
    const modal = document.getElementById('payment-modal');
    modal.classList.remove('hidden');
    
    // Puedes guardar el ID por si lo necesitas enviar
    modal.dataset.templateId = templateId;
  }

  document.getElementById('close-modal')?.addEventListener('click', () => {
    document.getElementById('payment-modal')?.classList.add('hidden');
  });
</script>
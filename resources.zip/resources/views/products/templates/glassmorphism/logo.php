<html>
<head>  
  <meta charset="UTF-8" />  
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />  
  <title>redLights()</title>  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" />  
  <script src="https://cdn.tailwindcss.com"></script>  
</head>  

<body>
<div class="min-h-screen flex items-center justify-center bg-gradient-to-br from-gray-900 via-purple-900 to-black p-4">
  <div class="backdrop-blur-md bg-white/10 border border-white/20 rounded-2xl shadow-lg p-8 max-w-sm w-full">
    <h2 class="text-white text-2xl font-bold mb-4">Glassmorphism Card</h2>
    <p class="text-white/80 mb-4">Este es un ejemplo con fondo transparente y efecto blur.</p>
    <button class="bg-white/20 hover:bg-white/30 text-white font-semibold py-2 px-4 rounded-xl transition">
      Acción
    </button>
  </div>
</div>

</body>
</html>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>redLights( )</title>

  <!-- Tailwind CSS -->
  <script src="https://cdn.tailwindcss.com"></script>
  
  <!-- Iconos Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" />

  <!-- Meta SEO -->
  <meta name="description" content="Plantilla lista para subir con diseño moderno tipo glassmorphism, estilo redLights." />
</head>

<body class="bg-gradient-to-br from-white via-white to-white text-grey-800 min-h-screen flex flex-col">

  <!-- Header -->
  <header class="bg-[rgba(222,235,234,.8)] backdrop-blur-md border-b border-cyan-800">
    <div class="max-w-6xl mx-auto p-4 flex justify-between items-center">
      <h1 class="text-xl font-bold">redLights ( )</h1>
      <nav>
        <ul class="flex gap-6 text-sm text-gray-700">
          <li><a href="#inicio" class="hover:text-white transition">Inicio</a></li>
          <li><a href="#servicios" class="hover:text-white transition">Servicios</a></li>
          <li><a href="#contacto" class="hover:text-white transition">Contacto</a></li>
        </ul>
      </nav>
    </div>
  </header>

  <!-- Main -->
  <main class="flex-grow flex flex-col items-center justify-center text-center px-4">

    <!-- Hero Section -->
    <section id="inicio" class="py-12">
      <h2 class="text-gray-800 text-4xl font-bold mb-4">Bienvenido a <span class="text-cyan-700">redLights ( )</span></h2>
      <p class="text-gray-800 max-w-xl mx-auto">Tu punto de partida para plantillas modernas, elegantes y con glassmorphism.</p>
    </section>

    <!-- Card Glassmorphism -->
    <section class="backdrop-blur-md bg-[rgba(222,235,234,.8)] border border-cyan-800 rounded-2xl shadow-lg p-8 max-w-sm w-full mb-12">
      <h3 class="text-gray-800 text-2xl font-semibold mb-4">Glassmorphism Card</h3>
      <p class="text-gray-700 mb-4">Este componente es ideal para mostrar info destacada con estilo moderno.</p>
      <button class="bg-cyan-800 hover:bg-cyan-700 text-white font-semibold py-2 px-4 rounded-xl transition">
        Acción
      </button>
    </section>

    <!-- Servicios -->
    <section id="servicios" class="max-w-4xl w-full px-6">
      <h3 class="text-2xl text-gray-800 font-bold mb-6">Servicios</h3>
      <div class="grid md:grid-cols-3 gap-6">
        <div class="bg-white/10 backdrop-blur-sm p-4 rounded-xl border border-white/20">
          <i class="fas fa-code text-cyan-800 text-2xl mb-2"></i>
          <h4 class="font-bold text-gray-800 text-lg">Desarrollo Web</h4>
          <p class="text-gray-700 text-sm">Sitios rápidos, seguros y modernos.</p>
        </div>
        <div class="bg-white/10 backdrop-blur-sm p-4 rounded-xl border border-white/20">
          <i class="fas fa-paint-brush text-cyan-800 text-2xl mb-2"></i>
          <h4 class="font-bold text-gray-800 text-lg">Diseño UI</h4>
          <p class="text-gray-700 text-sm">Interfaz atractiva con enfoque visual.</p>
        </div>
        <div class="bg-white/10 backdrop-blur-sm p-4 rounded-xl border border-white/20">
          <i class="fas fa-mobile-alt text-cyan-800 text-2xl mb-2"></i>
          <h4 class="font-bold text-gray-800 text-lg">Responsive</h4>
          <p class="text-gray-700 text-sm">Compatible con todos los dispositivos.</p>
        </div>
      </div>
    </section>
    
    <!-- Sobre Nosotros -->
<section id="sobre" class="max-w-5xl mx-auto py-16 px-6 text-center">
  <h3 class="text-3xl text-gray-800 font-bold mb-6">Sobre Nosotros</h3>

  <div class="flex flex-col md:flex-row items-center gap-8">
    
    <!-- Imagen decorativa -->
    <img src="https://picsum.photos/400/300?grayscale" 
         alt="Sobre Nosotros" 
         class="rounded-xl shadow-lg w-full md:w-1/2 object-cover border border-white/20" />

    <!-- Texto + botón -->
    <div class="md:w-1/2 text-gray-700 text-left">
      <p class="mb-6 leading-relaxed">
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam. Eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.
      </p>
      <a href="#contacto" class="inline-block bg-cyan-800 hover:bg-cyan-700 text-white font-semibold py-2 px-6 rounded-xl transition duration-200">
        Contáctanos
      </a>
    </div>
  </div>
</section>

<!-- Misión -->
<section id="mision" class="max-w-5xl mx-auto py-16 px-6">
  <div class="border border-cyan-800 rounded-2xl backdrop-blur-md bg-[rgba(222,235,234,.8)] shadow-lg p-8 flex flex-col md:flex-row-reverse items-center gap-8">
    
    <!-- Imagen decorativa derecha -->
    <img src="https://picsum.photos/400/300?blur" 
         alt="Misión redLights" 
         class="rounded-xl w-full md:w-1/2 object-cover border border-white/10 shadow-md" />

    <!-- Texto lado izquierdo -->
    <div class="md:w-1/2 text-white/80 text-left">
      <h3 class="text-3xl font-bold mb-4 text-gray-800">Nuestra Misión</h3>
      <p class="mb-6 text-gray-700 leading-relaxed">
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?
      </p>
      <a href="#inicio" class="inline-block bg-cyan-800 hover:bg-cyan-700 text-white font-semibold py-2 px-6 rounded-xl transition duration-200">
        Conócenos más
      </a>
    </div>

  </div>
</section>

  </main>

  <!-- Footer -->
  <footer class="bg-cyan-800 backdrop-blur-md border-t border-cyan-800 p-4 text-center text-xs text-white">
    &copy; 2025 redLights(). Todos los derechos reservados.
  </footer>

</body>
</html>
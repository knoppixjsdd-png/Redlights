<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Ingeniería Civil - Plantilla</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-white text-gray-800 font-sans">

  <!-- Hero principal -->
  <section class="bg-[url('https://picsum.photos/1200/600?grayscale')] bg-cover bg-center text-white py-28 px-6">
    <div class="max-w-5xl mx-auto text-center bg-black/50 p-8 rounded-xl">
      <h1 class="text-4xl sm:text-5xl font-bold mb-4">Construimos con precisión</h1>
      <p class="text-lg sm:text-xl text-gray-200">Soluciones en ingeniería civil para tus proyectos más exigentes</p>
    </div>
  </section>

  <!-- Servicios -->
  <section class="max-w-6xl mx-auto px-6 py-20">
    <h2 class="text-3xl font-semibold text-center mb-10">Nuestros Servicios</h2>
    <div class="grid md:grid-cols-3 gap-8 text-center">
      <div class="p-6 bg-gray-100 rounded-xl shadow">
        <h3 class="text-xl font-bold mb-2">Diseño estructural</h3>
        <p class="text-sm text-gray-600">Cálculos y planos para cimentación, estructuras metálicas y concreto armado.</p>
      </div>
      <div class="p-6 bg-gray-100 rounded-xl shadow">
        <h3 class="text-xl font-bold mb-2">Supervisión de obra</h3>
        <p class="text-sm text-gray-600">Seguimiento técnico y control de calidad en cada etapa constructiva.</p>
      </div>
      <div class="p-6 bg-gray-100 rounded-xl shadow">
        <h3 class="text-xl font-bold mb-2">Topografía y proyectos</h3>
        <p class="text-sm text-gray-600">Estudios topográficos y desarrollo completo de proyectos civiles.</p>
      </div>
    </div>
  </section>

  <!-- Galería visual -->
  <section class="bg-gray-50 py-20 px-6">
    <h2 class="text-3xl font-semibold text-center mb-10">Obras realizadas</h2>
    <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 max-w-6xl mx-auto">
      <img src="https://picsum.photos/400/300?random=1" class="rounded-lg shadow" alt="obra" />
      <img src="https://picsum.photos/400/300?random=2" class="rounded-lg shadow" alt="obra" />
      <img src="https://picsum.photos/400/300?random=3" class="rounded-lg shadow" alt="obra" />
      <img src="https://picsum.photos/400/300?random=4" class="rounded-lg shadow" alt="obra" />
      <img src="https://picsum.photos/400/300?random=5" class="rounded-lg shadow" alt="obra" />
      <img src="https://picsum.photos/400/300?random=6" class="rounded-lg shadow" alt="obra" />
    </div>
  </section>

  <!-- Sobre el ingeniero -->
  <section class="max-w-5xl mx-auto px-6 py-20">
    <div class="text-center">
      <h2 class="text-3xl font-semibold mb-4">Ing. Carlos Mendoza</h2>
      <p class="text-gray-600 max-w-2xl mx-auto">Cédula profesional 12345678. Con más de 12 años de experiencia en proyectos de construcción, infraestructura y supervisión de obra. Apasionado por la seguridad, eficiencia y calidad estructural.</p>
    </div>
  </section>

  <!-- Formulario decorativo -->
  <section class="bg-white py-20 px-6">
    <div class="max-w-4xl mx-auto bg-gray-100 p-10 rounded-2xl shadow-lg">
      <h3 class="text-2xl font-semibold text-center mb-6">Contáctanos</h3>
      <form class="space-y-6">
        <div class="grid sm:grid-cols-2 gap-4">
          <input type="text" placeholder="Nombre completo" class="w-full p-3 border border-gray-300 rounded-lg" disabled />
          <input type="email" placeholder="Correo electrónico" class="w-full p-3 border border-gray-300 rounded-lg" disabled />
        </div>
        <textarea rows="4" placeholder="Mensaje" class="w-full p-3 border border-gray-300 rounded-lg resize-none" disabled></textarea>
        <div class="text-center">
          <button class="bg-gray-300 text-gray-700 px-6 py-3 rounded-lg cursor-not-allowed opacity-60">Enviar (solo diseño)</button>
        </div>
      </form>
    </div>
  </section>

  <!-- Footer -->
  <footer class="bg-gray-800 text-white text-center text-sm p-4">
    &copy; 2025 Ingeniería Mendoza. Todos los derechos reservados.
  </footer>

</body>
</html>
<?php
$galeria = [
  'Plantillas Web' => [
    ['titulo' => 'Landing Page', 'descripcion' => 'Diseño limpio.', 'src' => 'https://picsum.photos/1200/600?random=1'],
    ['titulo' => 'Ecommerce', 'descripcion' => 'Plantilla tienda.', 'src' => 'https://picsum.photos/1200/600?random=2'],
  ],
  'Logos' => [
    ['titulo' => 'Logo Tech', 'descripcion' => 'Estilo futurista.', 'src' => 'https://picsum.photos/1200/600?random=3'],
    ['titulo' => 'Logo Pro', 'descripcion' => 'Diseño profesional.', 'src' => 'https://picsum.photos/1200/600?random=4'],
  ],
  'Promocionales' => [
    ['titulo' => 'Banner Oferta', 'descripcion' => 'Para descuentos.', 'src' => 'https://picsum.photos/1200/600?random=5'],
    ['titulo' => 'Promo Evento', 'descripcion' => 'Promoción especial.', 'src' => 'https://picsum.photos/1200/600?random=6'],
  ]
];

$imagenes_json = [];
foreach ($galeria as $categoria => $imgs) {
  foreach ($imgs as $img) {
    $img['categoria'] = $categoria;
    $imagenes_json[] = $img;
  }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>redLights() - Carrusel por Categorías</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-br from-white via-gray-100 to-white min-h-screen text-gray-900">

  <!-- Header -->
  <header class="bg-gray-800 text-white py-4 px-6">
    <div class="max-w-6xl mx-auto flex justify-between items-center">
      <h1 class="text-2xl font-bold">redLights()</h1>
      <nav class="text-sm space-x-4">
        <a href="#" class="hover:underline">Inicio</a>
        <a href="#" class="hover:underline">Servicios</a>
        <a href="#" class="hover:underline">Contacto</a>
      </nav>
    </div>
  </header>

  <!-- Título -->
  <div class="text-center mt-10">
    <h2 class="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-gray-800 to-gray-500">
      Carrusel por Categorías
    </h2>
    <p class="text-gray-700 mt-2 text-lg">Selecciona una o varias categorías para ver imágenes relacionadas</p>
  </div>

  <!-- Multiselect -->
  <div class="max-w-xl mx-auto mt-6 text-center">
    <label class="block mb-2 font-semibold text-gray-800">Categorías:</label>
    <select id="categorySelect" multiple class="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400">
      <?php foreach ($galeria as $categoria => $imagenes): ?>
        <option value="<?= htmlspecialchars($categoria) ?>" <?= $categoria === 'Plantillas Web' ? 'selected' : '' ?>>
          <?= htmlspecialchars($categoria) ?>
        </option>
      <?php endforeach; ?>
    </select>
  </div>
  


  <!-- Carrusel -->
  <div class="relative w-full max-w-5xl mt-10 overflow-hidden rounded-xl shadow-xl">
    <div id="slider" class="flex transition-transform duration-500"></div>

    <!-- Controles -->
    <button onclick="slide(-1)" class="absolute top-1/2 -translate-y-1/2 left-4 bg-black/50 hover:bg-black text-white p-2 rounded-full z-10">
      &#8592;
    </button>
    <button onclick="slide(1)" class="absolute top-1/2 -translate-y-1/2 right-4 bg-black/50 hover:bg-black text-white p-2 rounded-full z-10">
      &#8594;
    </button>
  </div>
  
  <!-- Paquetes / Promocionales -->
<section class="max-w-6xl mx-auto px-6 mt-20">
  <h3 class="text-3xl font-semibold text-gray-800 text-center mb-10">Paquetes Disponibles</h3>
  <div class="grid gap-8 md:grid-cols-3">
    <!-- Paquete 1 -->
    <div class="bg-white rounded-xl shadow-md p-6 text-center hover:shadow-xl transition">
      <h4 class="text-xl font-bold text-gray-900 mb-2">Sesión Básica</h4>
      <p class="text-gray-600 mb-4">1 hora · 10 fotos editadas</p>
      <div class="text-2xl font-bold text-pink-600 mb-4">$800 MXN</div>
      <p class="text-sm text-gray-500">Ideal para retratos personales o redes sociales.</p>
    </div>

    <!-- Paquete 2 -->
    <div class="bg-white rounded-xl shadow-md p-6 text-center hover:shadow-xl transition border-2 border-pink-500">
      <h4 class="text-xl font-bold text-gray-900 mb-2">Sesión Profesional</h4>
      <p class="text-gray-600 mb-4">2 horas · 20 fotos editadas + video</p>
      <div class="text-2xl font-bold text-pink-600 mb-4">$1,500 MXN</div>
      <p class="text-sm text-gray-500">Perfecta para portafolios, eventos o productos.</p>
    </div>

    <!-- Paquete 3 -->
    <div class="bg-white rounded-xl shadow-md p-6 text-center hover:shadow-xl transition">
      <h4 class="text-xl font-bold text-gray-900 mb-2">Evento Completo</h4>
      <p class="text-gray-600 mb-4">Cobertura 6 hrs · Álbum + galería digital</p>
      <div class="text-2xl font-bold text-pink-600 mb-4">$4,200 MXN</div>
      <p class="text-sm text-gray-500">Ideal para bodas, XV años o eventos corporativos.</p>
    </div>
  </div>
</section>
  
    <!-- Formulario decorativo -->
<section class="max-w-4xl mx-auto mt-20 px-6">
  <div class="bg-white rounded-2xl shadow-lg p-8 sm:p-12">
    <h3 class="text-3xl font-semibold text-gray-800 mb-6 text-center">Contáctame</h3>
    <form class="space-y-6">
      <div class="grid sm:grid-cols-2 gap-4">
        <input type="text" placeholder="Tu nombre" class="w-full p-3 border border-gray-300 rounded-lg focus:outline-none" disabled />
        <input type="email" placeholder="Tu correo" class="w-full p-3 border border-gray-300 rounded-lg focus:outline-none" disabled />
      </div>
      <textarea rows="4" placeholder="Escribe tu mensaje..." class="w-full p-3 border border-gray-300 rounded-lg focus:outline-none resize-none" disabled></textarea>
      <div class="text-center">
        <button type="button" class="bg-gray-300 text-gray-600 px-6 py-3 rounded-lg cursor-not-allowed opacity-60">
          Enviar mensaje (solo diseño)
        </button>
      </div>
    </form>
  </div>
</section>

<!-- Footer -->
  <footer class="bg-gray-500 mt-9 backdrop-blur-md border-t border-white/20 p-4 text-center text-xs text-white/60">
    &copy; 2025 redLights(). Todos los derechos reservados.
  </footer>

  <!-- Script -->
  <script>
    const imagenes = <?= json_encode($imagenes_json) ?>;
    const slider = document.getElementById('slider');
    const categorySelect = document.getElementById('categorySelect');
    let currentIndex = 0;

    function updateSlider() {
      const selected = Array.from(categorySelect.selectedOptions).map(opt => opt.value);
      const filtradas = imagenes.filter(img => selected.includes(img.categoria));
      slider.innerHTML = '';

      if (filtradas.length === 0) {
        slider.innerHTML = `<div class="min-w-full flex items-center justify-center text-xl text-gray-600 font-semibold">
                              Selecciona una categoría para mostrar imágenes.
                            </div>`;
        return;
      }

      filtradas.forEach(img => {
        const div = document.createElement('div');
        div.className = 'w-full flex-shrink-0 relative px-2 box-border';
        div.innerHTML = `
  <div class="relative w-full h-full flex justify-center items-end">
    <img src="${img.src}" class="w-full max-h-[500px] object-contain rounded-xl" />
    <div class="absolute bottom-0 w-full bg-black/60 text-white px-6 py-4 rounded-b-xl">
      <h3 class="text-lg font-semibold">${img.titulo}</h3>
      <p class="text-sm">${img.descripcion}</p>
    </div>
  </div>
`;
        slider.appendChild(div);
      });

      currentIndex = 0;
      slider.style.transform = `translateX(0%)`;
    }

    function slide(direction) {
      const total = slider.children.length;
      if (total === 0) return;
      currentIndex += direction;
      if (currentIndex < 0) currentIndex = total - 1;
      if (currentIndex >= total) currentIndex = 0;
      slider.style.transform = `translateX(-${currentIndex * 100}%)`;
    }

    categorySelect.addEventListener('change', updateSlider);
    updateSlider();
  </script>

</body>
</html>
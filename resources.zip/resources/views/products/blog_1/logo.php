<html>
<head>  
  <meta charset="UTF-8" />  
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />  
  <title>RedLights Azul Pro</title>  
  <script src="https://cdn.tailwindcss.com"></script>  
  <style>
    html, body {
      height: 100%;
      margin: 0;
    }
  </style>
</head>  

<body class="bg-gradient-to-br from-blue-950 via-blue-900 to-blue-800 h-full flex items-center justify-center p-4">

  <div class="bg-blue-800 text-white rounded-2xl shadow-xl p-5 w-full max-w-sm h-full flex flex-col justify-between border border-blue-700">
    
    <!-- Encabezado -->
    <div class="text-center">
      <h2 class="text-xl font-bold mb-1">Plantilla Azul Pro</h2>
      <p class="text-blue-200 text-sm">Diseño moderno con tamaño optimizado</p>
    </div>

    <!-- Imagen perfectamente encajada -->
    <div class="overflow-hidden rounded-lg mt-3">
      <img src="https://source.unsplash.com/random/400x200" alt="Preview"
           class="w-full h-48 object-cover border border-white/10 shadow-md rounded-md" />
    </div>

    <!-- Botón con efecto -->
    <div class="mt-4">
      <button class="w-full bg-black text-white font-semibold py-2 px-4 rounded-xl 
                     hover:bg-white hover:text-black hover:scale-105 transition-all duration-300 ease-in-out">
        Ver plantilla
      </button>
    </div>
    
  </div>

</body>
</html>
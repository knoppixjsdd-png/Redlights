<?php
$proyectos = [
    [
        "ruta" => "products/templates",
        "nombre" => "Plantillas",
        "descripcion" => "Plantillas con tematicas variadas",
        "imagen" => "https://via.placeholder.com/300?text=Tienda"
    ],
    [
        "ruta" => "home",
        "nombre" => "Portafolio Creativo",
        "descripcion" => "Dise�0�9o elegante para mostrar proyectos personales.",
        "imagen" => "https://via.placeholder.com/300?text=Portafolio"
    ],
    [
        "ruta" => "products",
        "nombre" => "Landing de App M��vil",
        "descripcion" => "P��gina de aterrizaje moderna para apps m��viles.",
        "imagen" => "https://via.placeholder.com/300?text=App"
    ],
    [
        "ruta" => "products",
        "nombre" => "Dashboard Admin",
        "descripcion" => "Panel de administraci��n con gr��ficas y widgets.",
        "imagen" => "https://via.placeholder.com/300?text=Dashboard"
    ],
];
?>

<!-- Secci��n de Proyectos -->
<section class="max-w-6xl mx-auto px-6 py-9 bg-white text-white">
    <h2 class="text-3xl text-black mb-6">Nuestros Productos<span class="text-red-500">.</span></h2>
    <div class="grid md:grid-cols-3 gap-6">
        <?php foreach ($proyectos as $proyecto): ?>
            <a href="<?= $proyecto['ruta'] ?>">
            <div class="bg-black p-4 rounded-xl shadow-lg">
                <img src="<?= $proyecto['imagen'] ?>" alt="<?= $proyecto['nombre'] ?>" class="rounded-lg mb-3">
                <h3 class="text-xl text-white"><?= $proyecto['nombre'] ?></h3>
                <p class="text-gray-400"><?= $proyecto['descripcion'] ?> <span class="text-red-500">...</span></p>
            </div>
            </a>
        <?php endforeach; ?>
    </div>
</section>
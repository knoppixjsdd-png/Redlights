<div class="py-10 my-6">
<div class="max-w-6xl mx-auto py-10 px-6 text-white">
    <h1 class="text-3xl font-bold mb-4">Bienvenido, <?= htmlspecialchars($user['name']) ?></h1>
    <p class="text-lg mb-6">Este es tu panel de control.</p>

    <div class="grid md:grid-cols-3 gap-6">
        <a href="/proyectos" class="block bg-black p-4 rounded-xl shadow-lg hover:shadow-xl hover:bg-gray-900 transition">
            <h2 class="text-xl font-bold text-red-500 mb-1">Proyectos</h2>
            <p class="text-gray-400">Gestiona tus proyectos aquí.</p>
        </a>

        <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
        <a href="/users" class="block bg-black p-4 rounded-xl shadow-lg hover:shadow-xl hover:bg-gray-900 transition">
            <h2 class="text-xl font-bold text-red-500 mb-1">Usuarios</h2>
            <p class="text-gray-400">Administra usuarios si eres admin.</p>
        </a>
        <?php endif; ?>

        <a href="/mi-cuenta" class="block bg-black p-4 rounded-xl shadow-lg hover:shadow-xl hover:bg-gray-900 transition">
            <h2 class="text-xl font-bold text-red-500 mb-1">Mi cuenta</h2>
            <p class="text-gray-400">Edita tu perfil y configuraciones.</p>
        </a>
    </div>
</div>
</div>
<?php

namespace Core;

class Router
{
    protected $routes = [];

    public function __construct()
    {
        $this->loadRoutes();
    }

    // Cargar las rutas desde el archivo web.php
    protected function loadRoutes()
    {
        $routesPath = __DIR__ . '/../routes/web.php';

        if (file_exists($routesPath)) {
            $this->routes = require $routesPath;
        } else {
            echo "Error: archivo de rutas no encontrado.";
        }
    }

    // Manejar la solicitud según la URL
    public function handleRequest($url)
    {
        $url = trim($url, '/');

        foreach ($this->routes as $route => $action) {
            $routeParts = explode('/', trim($route, '/'));
            $urlParts = explode('/', $url);

            if (count($routeParts) === count($urlParts)) {
                $params = [];
                $match = true;

                for ($i = 0; $i < count($routeParts); $i++) {
                    if (preg_match('/^{\w+}$/', $routeParts[$i])) {
                        $params[] = $urlParts[$i]; // es un parámetro, lo guardamos
                    } elseif ($routeParts[$i] !== $urlParts[$i]) {
                        $match = false;
                        break;
                    }
                }

                if ($match) {
                    list($controllerName, $method) = explode('@', $action);
                    $controllerClass = 'App\\Http\\Controllers\\' . $controllerName;
                    $controllerPath = __DIR__ . '/../app/Http/Controllers/' . $controllerName . '.php';

                    if (file_exists($controllerPath)) {
                        require_once $controllerPath;
                        if (class_exists($controllerClass)) {
                            $controller = new $controllerClass();
                            if (method_exists($controller, $method)) {
                                if ($_SERVER['REQUEST_METHOD'] === 'POST' && $url === 'logout') {
                                    return $controller->logout(); // Ejecutar solo si es POST y es logout
                                }
                                return call_user_func_array([$controller, $method], $params);
                                } else {
                                echo "Error: El método '$method' no existe.";
                            }
                        } else {
                            echo "Error: Clase '$controllerClass' no encontrada.";
                        }
                    }
                }
            }
        }

        echo "404 - Página no encontrada.";
    }
}
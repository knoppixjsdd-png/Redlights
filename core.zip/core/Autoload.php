<?php

spl_autoload_register(function ($class) {
    $prefixes = [
        'App\\Http\\Controllers\\' => __DIR__ . '/../app/Http/Controllers/',
        'Core\\' => __DIR__ . '/',
        'Models\\' => __DIR__ . '/../models/',
    ];

    foreach ($prefixes as $prefix => $base_dir) {
        if (strncmp($prefix, $class, strlen($prefix)) === 0) {
            $relative_class = substr($class, strlen($prefix));
            $file = $base_dir . str_replace('\\', '/', $relative_class) . '.php';

            if (file_exists($file)) {
                require $file;
                return;
            }
        }
    }
});



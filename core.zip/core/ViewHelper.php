<?php

namespace Core;

class ViewHelper
{
    public static function render($view, $data = [])
    {
        extract($data); // Extrae las variables para usar dentro de la vista

        $viewPath = __DIR__ . '/../resources/views/' . str_replace('.', '/', $view) . '.php';

        if (file_exists($viewPath)) {
            require __DIR__ . '/../public_html/header.php';
            require $viewPath;
            require __DIR__ . '/../public_html/footer.php';
        } else {
            echo "Vista '$view' no encontrada en $viewPath";
        }
    }
    
    public static function renderRaw($view, $data = [])
    {
        extract($data); // Extrae las variables para usar dentro de la vista

        $viewPath = __DIR__ . '/../resources/views/' . str_replace('.', '/', $view) . '.php';

        if (file_exists($viewPath)) {
            //require __DIR__ . '/../public_html/header.php';
            require $viewPath;
            //require __DIR__ . '/../public_html/footer.php';
        } else {
            echo "Vista '$view' no encontrada en $viewPath";
        }
    }
}
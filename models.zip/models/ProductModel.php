<?php
namespace Models;

use Core\Database;
use PDO;

class ProductModel
{
    private $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    // Retorna todos los templates y si han sido comprados por un usuario específico
    public function getTemplatesWithPurchaseStatus($userId = null)
    {
        $sql = "
            SELECT p.*, 
                   EXISTS (
                       SELECT 1 
                       FROM purchases 
                       WHERE purchases.product_id = p.id 
                       AND purchases.user_id = :user_id
                   ) AS purchased
            FROM products p
            WHERE p.type = 'template'
        ";

        $stmt = $this->db->prepare($sql);
        $stmt->execute(['user_id' => $userId ?? 0]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Retorna todos los productos tipo template, sin importar si se compraron
    public function getAllTemplates() 
    {
        $stmt = $this->db->prepare("SELECT * FROM products WHERE type = 'template'");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Puedes agregar más métodos personalizados aquí...
}
<?php
namespace App\Helpers;

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
//error_log("Mailer error: " . $this->mailer->ErrorInfo);

require_once __DIR__ . '/../../vendor/autoload.php';

class MailHelper
{
    private $mailer;

    public function __construct()
    {
        $this->mailer = new PHPMailer(true);

        // Configuraci�n SMTP
        $this->mailer->isSMTP();
        $this->mailer->Host       = 'smtp.titan.email';
        $this->mailer->SMTPAuth   = true;
        $this->mailer->Username   = 'no-reply@redlights.com.mx';
        $this->mailer->Password   = 'samahiHernandez(0)';
        $this->mailer->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        $this->mailer->Port       = 465;

        $this->mailer->setFrom('no-reply@redlights.com.mx', 'RedLights');
    }

    public function enviar($destinatario, $asunto, $mensaje)
    {
        try {
            $this->mailer->clearAddresses();
            $this->mailer->addAddress($destinatario);
            $this->mailer->isHTML(true);
            $this->mailer->Subject = $asunto;
            $this->mailer->Body    = $mensaje;

            return $this->mailer->send();
        } catch (Exception $e) {
            error_log("Error al enviar correo: {$this->mailer->ErrorInfo}");
            return false;
        }
    }

    public static function sendWelcomeEmail($destinatario, $nombre, $usuario)
    {
        $mensaje = "
            <h1>�Bienvenido a RedLights, {$nombre}!</h1>
            <p>Usuario: <strong>{$nombre}</strong></p>
            <p>Contrase�a: <strong>{$usuario}<strong></p>
            <p>Gracias por registrarte. Disfruta de la plataforma.</p>
        ";

        $instancia = new self();
        return $instancia->enviar($destinatario, 'Bienvenido a RedLights', $mensaje);
    }
}



<?php
namespace App\Http\Controllers;

class DashboardController {
    public function index() {
        if (!isset($_SESSION['user_id'])) {
            header('Location: /login');
            exit;
        }

        \Core\ViewHelper::render('dashboard.index', [
            'user' => $_SESSION
        ]);
    }
}
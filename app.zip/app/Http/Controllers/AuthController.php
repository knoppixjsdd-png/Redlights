<?php
namespace App\Http\Controllers;

use Models\UserModel;

class AuthController {
    public function login() {
        //session_start();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = trim($_POST['email']);
            $password = $_POST['password'];
            //$name = $_POST['name'];

            $userModel = new UserModel();
            $user = $userModel->getUserByEmail($email);

            if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user'] = $user; 
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['role'] = $user['role'] ?? 'usuario';
            $_SESSION['name'] = $user['name'] ?? 'Usuario';

            // 👇 ESTO es lo nuevo
            $redirect = $_POST['redirect'] ?? '/dashboard';
            header("Location: $redirect");
            exit;
        } else {
            echo "Correo o contrase単a incorrectos.";
            }
        } else {
    // Mostrar la vista de login
    $redirect = $_GET['redirect'] ?? '/dashboard';
    \Core\ViewHelper::render('auth.login', ['redirect' => $redirect]);
}
    }
    
    public function logout()
    {
        session_unset();
        session_destroy();
        header('Location: /login');
        exit;
    }
    
    public function googleLogin()
{
    $redirect = $_GET['redirect'] ?? '/';
    $_SESSION['redirect_after_login'] = $redirect;

    header('Location: /google-login.php');
    exit;
}


    /*public function googleLogin()
    {
        //header('Location: google-login');
        header('Location: /google-login.php');
        exit;
    }*/

    public function googleCallback()
    {
        require_once 'public_html/google-callback.php';
    }

}

//__DIR__ . '/../public_html/header.php'
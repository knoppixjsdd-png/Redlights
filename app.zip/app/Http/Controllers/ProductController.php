<?php
namespace App\Http\Controllers;

use Core\ViewHelper;
use Models\ProductModel;

class ProductController
{
    public function index()
    {
        $model = new ProductModel();
        $products = $model->getAllProducts(); // Este m¨¦todo debe existir
        $data = [
            'title' => 'Productos de RedLights',
            'products' => $products,
        ];

        ViewHelper::render('products/index', $data);
    }

    public function templates()
{
    $model = new ProductModel();
    $userId = $_SESSION['user_id'] ?? 0;

    // Obtener templates desde la BD
    $templates = $model->getTemplatesWithPurchaseStatus($userId);

    $data = [
        'title' => 'Templates de RedLights',
        'templates' => $templates
    ];

    ViewHelper::render('products/templates/index', $data);
}
    
    public function templateView($folder, $tipo)
{       
    $model = new ProductModel();
    $templates = $model->getAllTemplates(); // ✅ método bien llamado

    $data = [
        'templates' => $templates // ✅ nombre claro y estándar
    ];    

    // Validación básica de tipo permitido
    if (!in_array($tipo, ['views', 'images'])) {
        echo "Vista no permitida.";
        return;
    }

    // Armamos la ruta
    $path = "products/templates/{$folder}/{$tipo}";
    $fullPath = __DIR__ . "/../../../resources/views/{$path}.php";

    // Validación de existencia del archivo
    if (!file_exists($fullPath)) {
        echo "Vista no encontrada.";
        return;
    }

    // Renderiza la vista, pasando los templates como datos
    if ($tipo === 'views') {
        \Core\ViewHelper::renderRaw($path, $data);
    } else {
        \Core\ViewHelper::render($path, $data);
    }
}
}
<?php

namespace App\Http\Controllers;

use Core\ViewHelper;

class ViewsController
{
    public function home()
    {
        $data = [
            'title' => 'Bienvenido a RedLights',
        ];

        ViewHelper::render('home', $data);
    }

    // Puedes agregar más métodos para otras vistas, por ejemplo:
    public function login()
    {
        ViewHelper::render('auth.login');
    }
    
    public function about()
    {
        $data = [
            'title' => 'Acerca de RedLights',
        ];

        ViewHelper::render('about', $data);
    }
    
    public function contact()
    {
        $data = [
            'title' => 'Contacto de RedLights',
        ];

        ViewHelper::render('contact', $data);
    }
    
  /*public function product()
    {
        $data = [
            'title' => 'Product de RedLights',
        ];

        ViewHelper::render('product', $data);
    }*/
}
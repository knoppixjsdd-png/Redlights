<?php
namespace App\Http\Controllers;

use Core\ViewHelper;
use Models\UserModel;

class UserController
{
    public function index()
    {
        if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') {
        
          $model = new UserModel();
          $users = $model->getAllUsers();
          $data = [
            'users' => $users,
          ];
        \Core\ViewHelper::render('auth.users', $data);
        } else {
          header('Location: ../home');
            exit;
        }

    }

    public function create()
    {
        // Vista para crear un usuario
        $view = 'auth.createUser';
        $data = [];

        \Core\ViewHelper::render($view, $data);
    }

    public function store()
{
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $name = trim($_POST['name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $password = trim($_POST['password'] ?? '');

        if (!$name || !$email || !$password) {
            echo "Todos los campos son requeridos.";
            return;
        }

        $model = new \Models\UserModel(); // Define el modelo antes de usarlo

        if ($model->emailExists($email)) {
            echo "Este correo ya est� registrado.";
            return;
        }

        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $model->createUser($name, $email, $hashedPassword);

        header('Location: /users');
        exit;
    }
}

public function edit($id)
{
    $model = new UserModel();
    $user = $model->getUserById($id);

    if ($user) {
        \Core\ViewHelper::render('auth/editUser', ['user' => $user]);
    } else {
        echo "Usuario no encontrado.";
    }
}
public function update($id)
{
    if ($_POST) {
        $name = trim($_POST['name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $password = trim($_POST['password'] ?? '');

        // Solo hashear si hay nueva contrase�a
        $hashedPassword = $password !== '' ? password_hash($password, PASSWORD_DEFAULT) : null;

        $model = new \Models\UserModel();
        $model->updateUser($id, $name, $email, $hashedPassword);

        header('Location: /users');
        exit;
    }
}

    public function delete($id)
    {
        $model = new UserModel();
        $model->deleteUser($id);

        header('Location: /users');
    }
}
<?php
  $uri = $_SERVER['REQUEST_URI'];
  $isHome = $uri === '/home' || $uri === '/' || $uri === '/index.php';
?>
<!DOCTYPE html>
<html lang="es">  
<head>  
  <meta charset="UTF-8" />  
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />  
  <title>redLights()</title>  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" />  
  <script src="https://cdn.tailwindcss.com"></script>  
</head>  

<body class="bg-black text-white overflow-x-hidden">
  <header class="absolute top-0 left-0 w-full z-[9999] bg-transparent 
  <?php echo $isHome ? 'min-h-[337px] md:min-h-[420px]' : 'min-h-[80px]'; ?>">
   
    <!-- ########## BEGIN MENU ########## -->
    <div class="fixed flex items-center justify-between w-full p-2">
    
      <!-- ########## BEGIN SVG STAR ########## -->
      <div class="flex items-center space-x-2 px-4">
        <svg viewBox="0 0 350 200" class="w-24 h-24 pt-6">
          <defs>
            <radialGradient id="foco1" cx="50%" cy="50%" r="72%">
              <stop offset="60%" stop-color="black" />
              <stop offset="100%" stop-color="red" />
            </radialGradient>
            <radialGradient id="foco2" cx="50%" cy="50%" r="55%">
              <stop offset="60%" stop-color="black" />
              <stop offset="100%" stop-color="red" />
            </radialGradient>
          </defs>
          
          <circle cx="50" cy="60" r="45" fill="none" stroke="red" />
          <circle cx="50" cy="60" r="23" fill="none" stroke="red" />
          <path d="M45,45 Q50,-20 56,45 Q57,53 65,54 Q130,60 65,65 Q57,67 55,75 Q50,140 45,75 Q43,67 35,65 
                   Q-30,60 35,55 Q43,53 45,45 Z" fill="red" stroke="#000" stroke-width="3" />
      
        </svg>
        <span class=" text-red-600 text-xl font-bold">RedLights</span>  
      </div>
      <!-- ########## END SVG STAR ########## -->
    
      <!-- ########## BEGIN 9 POINT BUTTON ########## -->
      <div class="md:hidden pr-4">  
        <button id="menu-toggle" class="text-white focus:outline-none text-2xl">  
          <!-- Cuadro de 9 puntos en color oscuro -->
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="red" class="w-6 h-6">
            <path d="M4 4h4v4H4V4zm6 0h4v4h-4V4zm6 0h4v4h-4V4zM4 10h4v4H4v-4zm6 0h4v4h-4v-4zm6 
                     0h4v4h-4v-4zM4 16h4v4H4v-4zm6 0h4v4h-4v-4zm6 0h4v4h-4v-4z" stroke="#000" stroke-width="1" />
          </svg>
        </button>  
      </div>  
      <!-- ########## END 9 POINT BUTTON ########## -->

      <!-- ########## BEGIN DESKTOP MENU ########## -->
      <nav class="align-left hidden md:flex space-x-6 px-6 ">  
        <a href="/home" class="hover:text-red-900">Home</a>  
        <a href="/products/templates" class="hover:text-red-500">Plantillas</a>  
        <a href="/contact" class="hover:text-red-500">Contacto</a>  
        <a href="/about" class="hover:text-red-500">Sobre Nosotros</a>  
        <?php if (isset($_SESSION['user_id'])): ?>
          <a href="/dashboard" class="hover:text-red-500">Panel de control</a>
        <?php endif; ?>
      </nav>  
    
    <!-- ########## END DESKTOP MENU ########## -->
  
    
    <!-- ########## BEGIN MOBILE MENU ########## -->
      <nav id="mobile-menu" class="hidden md:hidden flex-col absolute top-[80px] left-0 w-full border-y border-red-700 z-[10000] transition-all duration-300 ease-in-out opacity-0 transform scale-y-0 origin-top bg-black">
    <a href="/home" class="block px-4 py-3 hover:bg-[#1A0000]">Home</a>
    <a href="/products/templates" class="block px-4 py-3 hover:bg-[#1A0000]">Plantillas</a>

    <?php if (!isset($_SESSION['user_id'])): ?>
        <a href="/login" class="block px-4 py-3 hover:bg-[#1A0000]">Iniciar sesión</a>
    <?php else: ?>
        <a href="/dashboard" class="block px-4 py-3 hover:bg-[#1A0000]">Panel de control</a>
        <a href="/logout" class="block px-4 py-3 hover:bg-[#1A0000]">Cerrar sesión</a>
    <?php endif; ?>
</nav>
    </div>
  </header>  
    <!-- ########## END MOBILE MENU ########## -->
  
  
  
  
  
  
  
  
  
  

<!-- public/footer.php -->
<footer class="bg-red-600 text-white mt-12 py-8">
  <div class="max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-3 gap-8 text-center md:text-left">
    
    <!-- Sección 1: Información de la empresa -->
    <div>
      <h3 class="text-lg font-semibold mb-2">Mi Sitio Web</h3>
      <p class="text-gray-400">&copy; 2025. Todos los derechos reservados.</p>
    </div>

    <!-- Sección 2: Enlaces rápidos -->
    <div>
      <h3 class="text-lg font-semibold mb-2">Enlaces</h3>
      <ul class="space-y-2">
        <li><a href="#" class="hover:text-red-500 block">Home</a></li>
        <li><a href="products/templates" class="hover:text-red-500 block">Plantillas</a></li>
        <li><a href="login" class="hover:text-red-500 block">Registrarse</a></li>
      </ul>
    </div>

    <!-- Sección 3: Redes sociales -->
    <div>
      <h3 class="text-lg font-semibold mb-2">Síguenos</h3>
      <div class="flex justify-center md:justify-start space-x-4">
        <a href="#" class="hover:text-red-500"><i class="fab fa-facebook fa-lg"></i></a>
        <a href="#" class="hover:text-red-500"><i class="fab fa-twitter fa-lg"></i></a>
        <a href="#" class="hover:text-red-500"><i class="fab fa-instagram fa-lg"></i></a>
      </div>
    </div>

  </div>
</footer>

<script>
  const toggle = document.getElementById('menu-toggle');
  const mobileMenu = document.getElementById('mobile-menu');

  const showMenu = () => {
    mobileMenu.classList.remove('hidden');
    setTimeout(() => {
      mobileMenu.classList.remove('opacity-0', 'scale-y-0');
    }, 10); // pequeña pausa para que la transición se aplique
  };

  const hideMenu = () => {
    mobileMenu.classList.add('opacity-0', 'scale-y-0');
    setTimeout(() => {
      mobileMenu.classList.add('hidden');
    }, 300); // coincide con duration-300
  };

  toggle.addEventListener('click', (e) => {
    e.stopPropagation();
    if (mobileMenu.classList.contains('hidden')) {
      showMenu();
    } else {
      hideMenu();
    }
  });

  document.addEventListener('click', (e) => {
    if (!mobileMenu.contains(e.target) && !toggle.contains(e.target)) {
      hideMenu();
    }
  });
</script>

<script src="https://js.stripe.com/v3/"></script>
<script>
  const stripe = Stripe("pk_test_51RVJpbEPx7lX43dw2mwHteUOUKQjRxZMjSQhlzJeczjRI1coKvVk6MOADgHVggvD4zAzChXbGD49qpb8aDiGB9oG00PbV7OBlU"); // tu clave pública real

  let card;

  async function openPaymentModal(templateId) {
    document.getElementById("payment-modal").classList.remove("hidden");

    // Obtener el clientSecret desde el servidor
    const response = await fetch("/checkout/create_payment_intent.php", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ template_id: templateId })
    });

    const data = await response.json();

    const elements = stripe.elements();
    card = elements.create("card");
    card.mount("#card-element");

    const form = document.getElementById("payment-form");
    form.onsubmit = async (e) => {
      e.preventDefault();
      const { error, paymentIntent } = await stripe.confirmCardPayment(data.clientSecret, {
        payment_method: { card: card }
      });

      const resultDiv = document.getElementById("payment-result");
      if (error) {
        resultDiv.textContent = "❌ " + error.message;
      } else {
        resultDiv.textContent = "✅ ¡Pago exitoso! ID: " + paymentIntent.id;
      }
    };
  }

  document.getElementById("close-modal").addEventListener("click", () => {
    document.getElementById("payment-modal").classList.add("hidden");
    document.getElementById("payment-result").textContent = "";
    if (card) card.unmount();
  });
</script>
</body>
</html>
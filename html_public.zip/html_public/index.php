<?php
session_start();

//echo file_exists(__DIR__ . '/vendor/autoload.php') ? 'Autoload encontrado' : 'Autoload NO encontrado';
require_once __DIR__ . '/../vendor/autoload.php';

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/../core/Autoload.php';

$router = new Core\Router();
$url = isset($_GET['url']) ? $_GET['url'] : 'home';

try {
    $router->handleRequest($url);
} catch (Throwable $e) {
    echo "<h2>Error capturado:</h2>";
    echo "<strong>Mensaje:</strong> " . $e->getMessage() . "<br>";
    echo "<strong>Archivo:</strong> " . $e->getFile() . "<br>";
    echo "<strong>Línea:</strong> " . $e->getLine() . "<br>";
    echo "<pre>" . $e->getTraceAsString() . "</pre>";
}